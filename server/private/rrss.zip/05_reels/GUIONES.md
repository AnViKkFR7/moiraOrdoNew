# Reels: 8 guiones y portadas

Guiones de 22–27 s aproximados. Pendientes de grabación, montaje, subtítulos y elección de audio. No se entregan vídeos terminados.

## R01 · Tu web, en tres preguntas.
Portada: `05_reels/R01_portada.png`

| Tiempo | Plano / texto |
|---|---|
| 0–3 s | Abre una web en el móvil. Texto: ¿Tu web lo pone fácil? |
| 3–8 s | Primer bloque: ¿Se entiende qué haces? |
| 8–13 s | Portfolio: ¿Se ve un ejemplo de tu trabajo? |
| 13–18 s | Contacto: ¿Está claro cómo escribirte? |
| 18–22 s | Cierre de marca: Guárdalo para revisar tu web. |

Caption sugerido:

Abre tu web desde el móvil y haz estas tres comprobaciones. Si alguna cuesta, ya tienes un punto por el que empezar. ¿Cuál revisarías primero?

#MoiraOrdo #DiseñoWeb #DesarrolloWeb

## R02 · Así empieza una web.
Portada: `05_reels/R02_portada.png`

| Tiempo | Plano / texto |
|---|---|
| 0–3 s | Plano de una libreta: Antes de diseñar, escuchamos. |
| 3–8 s | Escribe negocio / público / objetivo. |
| 8–14 s | Muestra un esquema de páginas ficticio y sin datos privados. |
| 14–20 s | Pasa al diseño de una sección del portfolio. |
| 20–25 s | Cierre: Cuéntanos qué necesitas en moiraordo.es/contacto. |

Caption sugerido:

Antes de las pantallas están las preguntas. Entender negocio, público y objetivos nos ayuda a decidir qué construir.

#MoiraOrdo #DiseñoWeb #DesarrolloWeb

## R03 · Una web. Tu contenido.
Portada: `05_reels/R03_portada.png`

| Tiempo | Plano / texto |
|---|---|
| 0–3 s | Texto: ¿Y si pudieras actualizarla tú? |
| 3–10 s | Graba la demo pública del CRM: abre Items y una ficha. |
| 10–17 s | Muestra un campo y una imagen de ejemplo. Etiqueta: Demo con datos ficticios. |
| 17–23 s | Vuelve a un proyecto de la web. |
| 23–27 s | Cierre: Cotillea la demo en moiraordo.es/crm. |

Caption sugerido:

Contenido que gestionas desde un panel, sobre un diseño cuidado. Esta grabación debe hacerse con la demo pública y datos ficticios.

#MoiraOrdo #DiseñoWeb #DesarrolloWeb

## R04 · Un proyecto, muchos detalles.
Portada: `05_reels/R04_portada.png`

| Tiempo | Plano / texto |
|---|---|
| 0–3 s | Portada de Arquelia: El trabajo merece verse. |
| 3–9 s | Scroll lento por el primer bloque y un proyecto. |
| 9–16 s | Acércate a tipografía, espaciados y fotografía. |
| 16–22 s | Muestra la misma página en móvil. |
| 22–26 s | Cierre: Proyecto Moira Ordo · arquelia.es. |

Caption sugerido:

Diseño editorial para presentar proyectos con detalle. Una mirada a Arquelia, parte de nuestro portfolio. Más en moiraordo.es/proyectos.

#MoiraOrdo #DiseñoWeb #DesarrolloWeb

## R05 · Más que una página web.
Portada: `05_reels/R05_portada.png`

| Tiempo | Plano / texto |
|---|---|
| 0–3 s | Portada de Vemaro: ¿Solo necesitas presentar tu negocio? |
| 3–10 s | Muestra el frontal público y el inicio del recorrido de reserva. |
| 10–16 s | Cartela: Reserva / precio / gestión. |
| 16–22 s | Muestra el portfolio de Moira Ordo, sin pantallas privadas. |
| 22–27 s | Cierre: Software a medida para necesidades concretas. |

Caption sugerido:

Vemaro Transfers es un ejemplo de cómo conectar una experiencia pública con herramientas para la operativa de una empresa. No completes reservas ni pagos para grabar.

#MoiraOrdo #DiseñoWeb #DesarrolloWeb

## R06 · El equipo detrás de la web.
Portada: `05_reels/R06_portada.png`

| Tiempo | Plano / texto |
|---|---|
| 0–3 s | Presentación: Somos Moira Ordo. |
| 3–9 s | Aaron a cámara: Arquitectura, desarrollo e integraciones. |
| 9–15 s | Joselyn a cámara: Diseño, frontend y acompañamiento. |
| 15–21 s | Fede a cámara: Marketing, SEO y publicidad. |
| 21–26 s | Plano de equipo: Hablemos de tu próximo proyecto. |

Caption sugerido:

Un equipo para conectar diseño, tecnología y marketing. Conócenos en moiraordo.es/#equipo. Graba planos propios con el equipo; la portada está preparada.

#MoiraOrdo #DiseñoWeb #DesarrolloWeb

## R07 · También se puede jugar.
Portada: `05_reels/R07_portada.png`

| Tiempo | Plano / texto |
|---|---|
| 0–3 s | Texto: No todo son webs corporativas. |
| 3–10 s | Graba una partida propia de MusiBingo. |
| 10–17 s | Graba una demo de MatchRise sin nombres de otros jugadores. |
| 17–22 s | Cartela: Juegos HTML5 · En el navegador. |
| 22–26 s | Cierre: ¿Una experiencia para tu marca o evento? |

Caption sugerido:

MusiBingo y MatchRise: dos formas de crear experiencias para el navegador. Utiliza audio propio o música con licencia para tu cuenta; no publiques canciones protegidas del juego.

#MoiraOrdo #DiseñoWeb #DesarrolloWeb

## R08 · Tu idea, con un siguiente paso.
Portada: `05_reels/R08_portada.png`

| Tiempo | Plano / texto |
|---|---|
| 0–3 s | Texto a cámara: No necesitas traerlo todo resuelto. |
| 3–9 s | Escribe tres preguntas: ¿Qué haces? ¿Qué cuesta? ¿Qué necesitas? |
| 9–16 s | Montaje breve de los proyectos del portfolio. |
| 16–22 s | Plano de equipo y web de contacto. |
| 22–26 s | Cierre: moiraordo.es/contacto · Escríbenos. |

Caption sugerido:

Si tienes una idea, podemos empezar por ordenarla. Cuéntanos qué hace tu negocio y qué te gustaría mejorar. Primera conversación desde moiraordo.es/contacto.

#MoiraOrdo #DiseñoWeb #DesarrolloWeb

# Fuentes del banco de contenido

Fecha de preparación: 28 de octubre de 2026.

## Datos del negocio

- `src/sections/Hero/Hero.jsx`: propuesta de valor y servicios de acompañamiento.
- `src/data/services.js`: diseño web, desarrollo web, diseño de marca, software y juegos.
- `src/pages/Projects/Projects.jsx`: portfolio y descripción de funciones.
- `src/sections/Team/Team.jsx`: nombres y funciones de Aaron, Joselyn y Fede.
- `src/pages/Crm/Crm.jsx` y `src/components/AdminPanelDemo`: áreas de la demo pública.
- `src/styles/variables.css` y `src/styles/fonts.css`: paleta y tipografías.
- `public/favicon.svg`: símbolo existente de la marca.

La lectura web automatizada de moiraordo.es no estuvo disponible. El contenido se ha contrastado con el código local del sitio; no se ha afirmado que las capturas representen cambios posteriores del despliegue.

## Recursos visuales

Copias del propio repositorio, en `_recursos`. Se usan las capturas del portfolio para Regia Mare, Navagli, Reformas Llobregat, Vemaro, MusiBingo y MatchRise. La imagen de Arquelia es una fotografía del portfolio, no una captura: se rotula como tal y no se dibuja un navegador a su alrededor.

La captura de Reformas Llobregat se recorta para no amplificar las cifras comerciales de la franja inferior. No se han inventado pantallas ni resultados.

La imagen `equipo-proceso.png` es un recurso visual ilustrativo del sitio: no se identifica a las personas que aparecen como miembros reales del equipo. La pieza P20 sí utiliza las imágenes de Aaron, Joselyn y Fede existentes en la web.

## Afirmaciones descartadas

`src/data/caseStudies.js` avisa expresamente de que sus métricas y testimonios necesitan validación con los clientes. Por eso no se usan ×4, +65 %, −60 %, valoraciones, porcentajes ni citas de clientes como argumentos del banco.

Los casos describen funciones y diseño, no prometen una mejora comercial. La demo del CRM se presenta con datos ficticios y no se equipara con una auditoría de todas las funciones desplegadas.

## Publicación

No se ha accedido a una cuenta de Instagram ni se ha publicado, enviado o programado ninguna pieza. No se ha comprobado disponibilidad de usuario. Los guiones que requieren grabaciones siguen pendientes de producir; no se simulan testimonios ni conversaciones reales.

# Banco de respuestas y llamadas a la acción

## CTA de conversación

- ¿Qué debería resolver tu próxima web?
- Cuéntanos qué necesita gestionar tu equipo.
- ¿Qué te gustaría poder actualizar sin pedir ayuda?
- ¿Qué parte de tu web revisarías primero?
- Si estás dando forma a una idea, empecemos por ordenarla.

## CTA de utilidad

- Guarda esta lista para revisar tu web.
- Compártelo con quien gestiona el contenido de tu negocio.
- Abre tu web desde el móvil y haz la prueba.
- Recorre el proyecto y fíjate en cómo se presenta el contenido.
- Explora la demo con datos ficticios.

## Respuestas sugeridas a comentarios o mensajes

**«¿Cuánto cuesta una web?»**
Gracias por escribirnos. El alcance cambia según páginas, contenido y funciones. Si nos cuentas qué hace tu negocio y qué necesitas, podemos orientarte y preparar una propuesta. El contacto está en moiraordo.es/contacto.

**«¿La puedo gestionar yo?»**
Podemos conectar la web a nuestro CRM para que actualices los contenidos definidos para tu proyecto desde un panel. Te enseñamos a usarlo. Puedes explorar una demo pública en moiraordo.es/crm.

**«Ya tengo web, pero quiero cambiarla.»**
Podemos empezar revisando qué funciona, qué cuesta y qué te gustaría mejorar. Así definimos si necesitas una evolución o un proyecto nuevo. Cuéntanos tu caso en moiraordo.es/contacto.

**«¿Lleváis SEO o publicidad?»**
Sí, el equipo también trabaja marketing, SEO y publicidad. Definimos qué tiene sentido para cada proyecto y cómo revisar sus resultados.

**«¿Cuánto tarda?»**
Depende del alcance y del contenido disponible. Lo concretamos al definir el proyecto, por fases y con entregas que se puedan revisar.

**«¿Usáis plantillas?»**
En los servicios de diseño a medida partimos de tu negocio, tu identidad y los recorridos de tus usuarios. El objetivo es que la solución responda a lo que necesitas.

**«¿Podemos hablar?»**
Claro. Escríbenos a info@moiraordo.es o cuéntanos tu proyecto en moiraordo.es/contacto y coordinamos el siguiente paso.

Son textos para adaptar a la conversación, no respuestas enviadas automáticamente.

# Textos de las 48 publicaciones

Cada bloque corresponde a los archivos con el mismo ID. Copia el caption sin el título editorial.

## P01 · Tu web. Tu contenido. Tu control.

Una web debería parecerse a tu negocio. Y deberías poder actualizarla sin pedir ayuda para cada cambio.

En Moira Ordo unimos diseño, desarrollo y un CRM propio: cuidamos cómo se ve tu web y cómo la gestionas después. Si además necesitas SEO o publicidad, el mismo equipo puede acompañarte.

Empezamos por entender qué haces y a quién quieres llegar.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P01.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Tu web. Tu contenido. Tu control.. Diseño a medida + CRM + un equipo que te acompaña.

## P02 · ¿Qué podemos hacer por ti?

Cuando tu web, tu contenido y tu marketing van por separado, aparecen las tareas repetidas y las conversaciones que no llegan a ninguna parte.

Podemos ayudarte con diseño web, desarrollo, marca, CRM, software a medida y juegos HTML5. También trabajamos el SEO y la publicidad cuando el proyecto lo necesita.

Desliza para ver cómo encajan las piezas.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P02/P02_01.png, 03_carruseles/P02/P02_02.png, 03_carruseles/P02/P02_03.png, 03_carruseles/P02/P02_04.png, 03_carruseles/P02/P02_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre servicios: ¿Qué podemos hacer por ti?. Un equipo para conectar las piezas de tu presencia digital.

**Alt por diapositiva:**
- Diapositiva 1/5: ¿Qué podemos hacer por ti?. Web, contenido y herramientas que trabajan juntos.
- Diapositiva 2/5: Una web con identidad.. Estructura, tipografía y diseño pensados para tu marca y para quien te visita.
- Diapositiva 3/5: Contenido que gestionas tú.. Textos, imágenes y catálogo desde un panel. El diseño conserva su coherencia.
- Diapositiva 4/5: Más allá del lanzamiento.. SEO, publicidad, mantenimiento y nuevas funciones según las necesidades del proyecto.
- Diapositiva 5/5: Hablemos de tu negocio.. Cuéntanos qué haces, qué necesitas y qué te gustaría mejorar. moiraordo.es/contacto

## P03 · Una web para abrir puertas.

En una inmobiliaria, el catálogo cambia y cada vivienda necesita contarse bien.

Para Regia Mare trabajamos una web a medida, multidioma y conectada a nuestro CRM. Las propiedades se presentan con fichas, atributos y filtros que ayudan a recorrer la oferta.

Una forma de conectar la presentación de cada inmueble con el trabajo diario del equipo.

Explora el proyecto: regiamare.com

Descubre el proyecto en regiamare.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P03.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Una web para abrir puertas.. Regia Mare · Catálogo inmobiliario y diseño a medida.

## P04 · Bonita, sí. Útil, también.

El diseño importa. También importa que una persona encuentre lo que busca.

Por eso trabajamos la jerarquía, la navegación, los textos y la versión móvil junto a la parte visual. Una buena primera impresión tiene que continuar con una experiencia clara.

Piensa en tu web: ¿qué debería poder hacer alguien en su primera visita?

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P04.png

**Texto alternativo:** Pieza de Moira Ordo sobre diseño: Bonita, sí. Útil, también.. Una buena web ayuda a entender, decidir y contactar.

## P05 · ¿Tu web lo pone fácil?

Abre tu web desde el móvil y mírala como si no conocieras tu negocio.

1. ¿Se entiende qué haces?
2. ¿Se encuentra un ejemplo de tu trabajo?
3. ¿Está claro cómo contactar?

No es una auditoría completa, pero sí una buena primera revisión. Si alguna respuesta cuesta, puede haber una oportunidad de mejora.

Guárdalo y revisa tu web con estas tres preguntas.

#ConsejosWeb #ExperienciaDeUsuario #WebParaNegocios #MoiraOrdo

**Archivos:** 02_posts/P05.png

**Texto alternativo:** Pieza de Moira Ordo sobre educación: ¿Tu web lo pone fácil?. Tres preguntas que ayudan a detectar fricción.

## P06 · El diseño empieza antes del diseño.

Antes de elegir colores, necesitamos entender el negocio.

Qué ofreces, quién te visita, qué dudas tiene y qué debería ocurrir después de entrar en la web. Con esa base definimos estructura, diseño y desarrollo.

Así trabajamos en Moira Ordo. Desliza para recorrer el proceso.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P06/P06_01.png, 03_carruseles/P06/P06_02.png, 03_carruseles/P06/P06_03.png, 03_carruseles/P06/P06_04.png, 03_carruseles/P06/P06_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre proceso: El diseño empieza antes del diseño.. Así damos forma a una web a medida.

**Alt por diapositiva:**
- Diapositiva 1/5: Primero, escuchar.. Qué hace tu negocio, quién es tu público y qué necesita resolver tu web.
- Diapositiva 2/5: Después, ordenar.. Definimos páginas, contenido y recorridos antes de diseñar pantallas.
- Diapositiva 3/5: Dar forma a tu identidad.. Trabajamos el diseño para escritorio, tablet y móvil como un mismo sistema.
- Diapositiva 4/5: Construir y comprobar.. Convertimos el diseño en una web y revisamos sus recorridos y funciones.
- Diapositiva 5/5: Publicar y acompañar.. Te enseñamos a gestionar el contenido y acordamos cómo seguir cuidando el proyecto.

## P07 · El trabajo bien hecho merece verse.

Una web de arquitectura y reformas necesita dar espacio al trabajo: imágenes, detalles y proyectos que cuentan una forma de hacer las cosas.

Arquelia reúne un diseño editorial a medida y contenido conectado a nuestro CRM. El proyecto también incluye trabajo de marketing online y publicidad.

Aquí compartimos una imagen utilizada en el portfolio de Moira Ordo para presentar el proyecto.

Puedes recorrerla en arquelia.es.

Explora el proyecto en arquelia.es.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P07.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: El trabajo bien hecho merece verse.. Arquelia · Una presentación editorial de sus proyectos.

## P08 · Cambiar una foto no debería ser un proyecto.

Una nueva obra. Una imagen actualizada. Un servicio que cambia.

Tu negocio se mueve y tu web necesita poder acompañarlo. Con nuestro CRM gestionas los contenidos previstos para tu proyecto desde un panel, sin editar el código de la web.

El contenido cambia; la identidad visual mantiene su orden.

Explora la demo en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P08.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: Cambiar una foto no debería ser un proyecto.. Tu contenido, desde un panel.

## P09 · Todo empieza con una buena conversación.

No hace falta llegar con un documento perfecto.

Nos ayuda saber qué hace tu negocio, qué te gustaría mejorar y qué herramientas utilizas hoy. A partir de ahí podemos definir prioridades y un alcance que tenga sentido.

La primera conversación sirve para entendernos.

Cuéntanos en qué estás trabajando: moiraordo.es/contacto.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P09.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Todo empieza con una buena conversación.. Escuchamos lo que necesitas antes de proponerte una solución.

## P10 · Una web clara desde el móvil.

La versión móvil merece una revisión propia. No basta con que los bloques quepan.

Hay que leer, navegar, tocar botones y completar formularios en una pantalla pequeña. En este carrusel repasamos decisiones que ayudan a que ese recorrido sea más sencillo.

¿Cuál revisarías primero en tu web?

Guárdalo para tu próxima revisión.

#ConsejosWeb #ExperienciaDeUsuario #WebParaNegocios #MoiraOrdo

**Archivos:** 03_carruseles/P10/P10_01.png, 03_carruseles/P10/P10_02.png, 03_carruseles/P10/P10_03.png, 03_carruseles/P10/P10_04.png, 03_carruseles/P10/P10_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre educación: Una web clara desde el móvil.. Cinco ideas para revisar tu experiencia móvil.

**Alt por diapositiva:**
- Diapositiva 1/5: Tu web, en pequeño.. ¿Se sigue entendiendo igual de bien cuando la abres desde el móvil?
- Diapositiva 2/5: Texto que se pueda leer.. Tamaño, contraste y párrafos que no conviertan la lectura en un esfuerzo.
- Diapositiva 3/5: Botones que se puedan tocar.. Acciones visibles, espacio alrededor y nombres que expliquen qué ocurrirá.
- Diapositiva 4/5: Formularios sin rodeos.. Pide lo que necesitas y explica qué campo falta cuando hay un error.
- Diapositiva 5/5: Pruébala como un cliente.. Abre un servicio, busca un ejemplo y envía una consulta de prueba con tu equipo.

## P11 · Proyectos nuevos. Contenido al día.

El portfolio de una empresa de reformas no se queda quieto. Cada proyecto terminado añade una nueva historia que mostrar.

Navagli cuenta con una web corporativa conectada a nuestro CRM para gestionar contenido y presentar su trabajo.

Diseñamos la web pensando también en las personas que la actualizarán después.

Conoce el proyecto: navagli.com.

Mira la web en navagli.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P11.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Proyectos nuevos. Contenido al día.. Navagli · Web corporativa conectada al CRM.

## P12 · Diseño con intención. Tecnología a medida.

Que una web se vea bien y que funcione bien forman parte del mismo trabajo.

En Moira Ordo conectamos la identidad visual con la estructura, el desarrollo y la gestión del contenido. El objetivo es construir una base que puedas usar y seguir ampliando.

Diseño con intención. Tecnología a medida.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P12.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Diseño con intención. Tecnología a medida.. Dos formas de cuidar el mismo proyecto.

## P13 · ¿Tu equipo trabaja con las mismas piezas?

Cuando una consulta entra por la web, el trabajo no termina en el formulario. Hay que revisar el contacto, darle seguimiento y organizar lo que viene después.

Nuestro panel reúne contenido, solicitudes, contactos, planning, presupuestos y facturación, con acceso por empresa y rol. La configuración se adapta a los módulos de cada proyecto.

La demo pública permite explorar estas áreas con datos ficticios.

Pruébala en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P13.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: ¿Tu equipo trabaja con las mismas piezas?. Contenido, contactos y documentos en un mismo panel.

## P14 · De visita a conversación.

¿Qué necesita saber alguien antes de escribirte?

Una propuesta clara, ejemplos de tu trabajo y una forma sencilla de contactar pueden ayudar a que la conversación empiece con contexto.

No hay un botón mágico: hay decisiones de contenido y diseño que merece la pena cuidar.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#ConsejosWeb #ExperienciaDeUsuario #WebParaNegocios #MoiraOrdo

**Archivos:** 03_carruseles/P14/P14_01.png, 03_carruseles/P14/P14_02.png, 03_carruseles/P14/P14_03.png, 03_carruseles/P14/P14_04.png, 03_carruseles/P14/P14_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre educación: De visita a conversación.. Un recorrido claro importa más que añadir botones.

**Alt por diapositiva:**
- Diapositiva 1/5: De visita a conversación.. Una web conecta lo que ofreces con lo que la persona necesita entender.
- Diapositiva 2/5: Explica qué resuelves.. Presenta tu servicio con palabras que utilice tu cliente, sin esconder lo importante.
- Diapositiva 3/5: Enseña tu trabajo.. Un proyecto real aporta contexto: qué era necesario y qué se construyó.
- Diapositiva 4/5: Invita a dar el paso.. Una llamada a la acción concreta y un formulario claro facilitan el contacto.
- Diapositiva 5/5: Cuida lo que pasa después.. Revisa las solicitudes, prepara la respuesta y mantén el seguimiento.

## P15 · Del trayecto a la reserva.

Hay negocios que necesitan algo más que una web de presentación.

Vemaro Transfers conecta una experiencia de reserva con una plataforma para gestionar flota, chóferes y servicios. El frontal incorpora presupuesto y pagos integrados.

Es un ejemplo de cómo un proyecto digital puede formar parte de la operativa de una empresa.

Descúbrelo en vemarotransfers.com.

Conoce el proyecto en vemarotransfers.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P15.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Del trayecto a la reserva.. Vemaro Transfers · Plataforma y gestión a medida.

## P16 · Una marca se reconoce en los detalles.

La identidad de tu negocio no termina en el logotipo.

Está en cómo se leen tus mensajes, cómo se ordenan las páginas y qué relación tienen las imágenes, los colores y la tipografía.

También diseñamos identidades de marca para que tu web y tus materiales compartan una base visual coherente.

¿Estás creando o revisando tu marca? Hablemos.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P16.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Una marca se reconoce en los detalles.. Logo, tipografía, color y una forma coherente de presentarte.

## P17 · Que te vean. Que te entiendan. Que te escriban.

Una web publicada necesita encontrar su lugar.

El SEO trabaja cómo se presenta y se encuentra tu contenido. La publicidad permite impulsar campañas concretas. El diseño y los textos ayudan a que la visita entienda tu propuesta.

En Moira Ordo podemos trabajar estas piezas con el mismo equipo, definiendo objetivos y revisando los datos sin prometer resultados automáticos.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#MarketingDigital #SEOLocal #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P17.png

**Texto alternativo:** Pieza de Moira Ordo sobre marketing: Que te vean. Que te entiendan. Que te escriban.. SEO, contenido y publicidad con un objetivo compartido.

## P18 · Antes de pedir una web.

Para empezar no necesitas conocer la tecnología. Sí ayuda compartir qué esperas del proyecto.

Este pequeño briefing sirve para ordenar la conversación: objetivo, público, contenido y gestión. Podemos ayudarte a concretarlo si todavía no lo tienes claro.

Guarda esta guía o úsala para escribirnos.

#ConsejosWeb #ExperienciaDeUsuario #WebParaNegocios #MoiraOrdo

**Archivos:** 03_carruseles/P18/P18_01.png, 03_carruseles/P18/P18_02.png, 03_carruseles/P18/P18_03.png, 03_carruseles/P18/P18_04.png, 03_carruseles/P18/P18_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre educación: Antes de pedir una web.. Lo que conviene poner sobre la mesa.

**Alt por diapositiva:**
- Diapositiva 1/5: Antes de pedir una web.. Cuatro preguntas para que la primera conversación sea más útil.
- Diapositiva 2/5: ¿Qué debe conseguir?. Presentar tus servicios, mostrar proyectos, recibir consultas o gestionar reservas.
- Diapositiva 3/5: ¿A quién va dirigida?. Quién te visita, qué busca y qué necesita saber para dar el siguiente paso.
- Diapositiva 4/5: ¿Qué contenido y gestión necesitas?. Textos, imágenes, catálogo, idiomas y personas que actualizarán la web.
- Diapositiva 5/5: ¿Qué es prioritario ahora?. Pongamos en orden alcance, presupuesto y fases. moiraordo.es/contacto

## P19 · Una forma clara de pedir presupuesto.

Para una empresa de reformas, una web puede ayudar a explicar servicios, mostrar trabajo y facilitar una primera consulta.

En Reformas Llobregat trabajamos una web orientada al contacto, junto con SEO local y publicidad.

La pieza muestra su diseño; las cifras de resultados necesitan su propia medición y contexto.

Recorre el proyecto en reformasllobregat.com.

Descubre reformasllobregat.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P19.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Una forma clara de pedir presupuesto.. Reformas Llobregat · Web, SEO local y publicidad.

## P20 · Un equipo. Tres miradas.

Lo digital se construye con distintas miradas.

Aaron trabaja la arquitectura, el desarrollo y las integraciones. Joselyn conecta diseño, frontend y acompañamiento al cliente. Fede se ocupa de marketing, SEO y publicidad.

Un equipo que puede acompañarte desde la primera idea hasta la evolución del proyecto.

Conócenos en moiraordo.es/#equipo.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P20.png

**Texto alternativo:** Pieza de Moira Ordo sobre equipo: Un equipo. Tres miradas.. Diseño, desarrollo y marketing alrededor de tu negocio.

## P21 · La web cambia. Tu identidad se mantiene.

Hay una diferencia entre actualizar contenido y tener que rediseñar una página cada vez.

En nuestro sistema, el panel gestiona los datos y la web los presenta siguiendo el diseño del proyecto. Puedes renovar los contenidos previstos sin entrar en el código.

Así damos espacio a que el negocio cambie sin perder su coherencia visual.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P21.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: La web cambia. Tu identidad se mantiene.. Contenido flexible sobre un diseño cuidado.

## P22 · ¿Qué puede vivir en tu CRM?

No todos los negocios necesitan las mismas herramientas. Por eso miramos primero cómo trabajas.

Contenido, contactos, agenda y documentos pueden convivir en un mismo panel con roles y empresas diferenciadas. En la demo pública puedes explorar estas áreas sin modificar datos reales.

Desliza para conocer algunas posibilidades.

Explora la demo: moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P22/P22_01.png, 03_carruseles/P22/P22_02.png, 03_carruseles/P22/P22_03.png, 03_carruseles/P22/P22_04.png, 03_carruseles/P22/P22_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: ¿Qué puede vivir en tu CRM?. Un vistazo al panel de Moira Ordo.

**Alt por diapositiva:**
- Diapositiva 1/5: Un panel para tu negocio.. La demo de Moira Ordo reúne ejemplos de gestión en un mismo lugar.
- Diapositiva 2/5: Tu contenido al día.. Items, imágenes y atributos para presentar los elementos de cada empresa.
- Diapositiva 3/5: Conversaciones con seguimiento.. Solicitudes y contactos con responsables, etapas y actividad.
- Diapositiva 4/5: Agenda y documentos.. Planning, presupuestos y facturación según los módulos del proyecto.
- Diapositiva 5/5: Cotillea la demo.. Datos ficticios y navegación libre. Nada se guarda. moiraordo.es/crm

## P23 · También construimos formas de jugar.

Además de webs y software, creamos experiencias jugables para navegador.

MusiBingo es un bingo musical para jugar en grupo. MatchRise es un manager de fútbol por rondas. Dos proyectos distintos que se abren con un enlace.

También podemos plantear juegos a medida para marcas, eventos o campañas.

Descubre MusiBingo en musibingo.com.

#JuegosHTML5 #DesarrolloDeJuegos #MoiraOrdoGames #MoiraOrdo

**Archivos:** 02_posts/P23.png

**Texto alternativo:** Pieza de Moira Ordo sobre games: También construimos formas de jugar.. Moira Ordo Games · Juegos HTML5 para navegador.

## P24 · Lo importante también está detrás.

Lo que se ve es solo una parte de una web.

También están la estructura del contenido, las integraciones y las decisiones que harán más sencillo ampliar el proyecto.

Trabajamos diseño y desarrollo juntos para que las funciones tengan sentido para tu negocio y la base se pueda seguir cuidando.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P24.png

**Texto alternativo:** Pieza de Moira Ordo sobre desarrollo: Lo importante también está detrás.. Estructura, mantenimiento y una base para seguir creciendo.

## P25 · Tu negocio no cabe en una plantilla.

Un estudio, una inmobiliaria y un servicio de transfers trabajan de formas distintas.

Sus webs también necesitan resolver cosas diferentes: presentar proyectos, explorar un catálogo o reservar un servicio.

El punto de partida en Moira Ordo es entender ese contexto y diseñar una solución con sentido.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P25.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Tu negocio no cabe en una plantilla.. Empezamos por tus necesidades, no por un catálogo de pantallas.

## P26 · Una web no termina al publicarla.

Publicar abre una nueva etapa.

Revisar el contenido, comprobar el contacto, cuidar el mantenimiento y decidir qué mejorar forma parte de mantener viva una presencia digital.

El acompañamiento se define según lo que necesite cada proyecto: merece la pena hablarlo desde el principio.

Guárdalo para tu próximo lanzamiento.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P26/P26_01.png, 03_carruseles/P26/P26_02.png, 03_carruseles/P26/P26_03.png, 03_carruseles/P26/P26_04.png, 03_carruseles/P26/P26_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre proceso: Una web no termina al publicarla.. Qué conviene cuidar después del lanzamiento.

**Alt por diapositiva:**
- Diapositiva 1/5: Publicar es solo el comienzo.. Tu web necesita acompañar a un negocio que sigue cambiando.
- Diapositiva 2/5: Contenido que sigue vigente.. Servicios, proyectos y datos de contacto revisados con cierta frecuencia.
- Diapositiva 3/5: Recorridos que funcionan.. Comprueba desde el móvil que la navegación y el contacto siguen siendo claros.
- Diapositiva 4/5: Revisar para mejorar.. Lee las consultas y los datos disponibles antes de decidir el siguiente cambio.
- Diapositiva 5/5: Un siguiente paso con sentido.. Acordamos mantenimiento, soporte y nuevas fases según lo que necesites.

## P27 · Construye. Adapta. Asciende.

Cada producto digital tiene su propio recorrido. También un juego.

En MatchRise, un manager de fútbol por rondas, el jugador toma decisiones sobre plantilla, formación y partido para avanzar entre divisiones.

Es otro de los proyectos de Moira Ordo Games: diseño y desarrollo al servicio de una experiencia jugable.

Puedes verlo en matchrise.es.

Conoce MatchRise en matchrise.es.

#JuegosHTML5 #DesarrolloDeJuegos #MoiraOrdoGames #MoiraOrdo

**Archivos:** 02_posts/P27.png

**Texto alternativo:** Pieza de Moira Ordo sobre games: Construye. Adapta. Asciende.. MatchRise · Un manager de fútbol que vive en el navegador.

## P28 · Tu proyecto, paso a paso.

No hace falta resolverlo todo el primer día.

Trabajamos por pasos: entender la necesidad, definir una estructura, diseñar, construir y revisar. Eso nos permite ordenar prioridades y conversar sobre decisiones concretas.

¿Tienes una idea que todavía no sabes cómo aterrizar?

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P28.png

**Texto alternativo:** Pieza de Moira Ordo sobre proceso: Tu proyecto, paso a paso.. Escuchar. Diseñar. Construir. Acompañar.

## P29 · ¿Qué debería resolver tu próxima web?

Quizá necesitas mostrar mejor tus proyectos. O recibir consultas con más contexto. O gestionar un catálogo que hoy te cuesta mantener al día.

Antes de hablar de pantallas, hablemos de ese trabajo.

Cuéntanos en comentarios qué debería resolver tu próxima web. Si prefieres hablar de tu caso en privado, puedes escribirnos.

Te leemos. moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P29.png

**Texto alternativo:** Pieza de Moira Ordo sobre conversación: ¿Qué debería resolver tu próxima web?. Una pregunta más útil que empezar por los colores.

## P30 · Hecho para negocios reales.

Una parte de nuestro portfolio, en una sola idea: cada negocio necesita una solución propia.

Regia Mare, Arquelia, Navagli, Reformas Llobregat y Vemaro Transfers son proyectos con recorridos y prioridades diferentes.

En moiraordo.es/proyectos puedes ver cómo se traduce ese contexto en diseño y funciones.

Explora el portfolio en moiraordo.es/proyectos.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P30/P30_01.png, 03_carruseles/P30/P30_02.png, 03_carruseles/P30/P30_03.png, 03_carruseles/P30/P30_04.png, 03_carruseles/P30/P30_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre portfolio: Hecho para negocios reales.. Webs, plataformas y experiencias con necesidades distintas.

**Alt por diapositiva:**
- Diapositiva 1/5: Hecho para negocios reales.. Una selección de nuestro portfolio. Cada proyecto parte de una necesidad distinta.
- Diapositiva 2/5: Regia Mare.. Catálogo inmobiliario, diseño a medida y contenido conectado al CRM.
- Diapositiva 3/5: Arquelia.. Diseño editorial y contenido para presentar sus proyectos. Imagen de nuestro portfolio.
- Diapositiva 4/5: Vemaro Transfers.. Reservas y plataforma de gestión para una empresa de transfers privados.
- Diapositiva 5/5: ¿Y el próximo proyecto?. Podría empezar con una conversación sobre tu negocio. moiraordo.es/contacto

## P31 · Diseñamos para quien va a usarlo.

Una web tiene más de una persona al otro lado.

Está quien entra para conocer tu negocio. Está quien necesita contactar. Y está el equipo que después publicará contenido o revisará las solicitudes.

Diseñamos pensando en esos recorridos, para que la experiencia tenga sentido a ambos lados.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P31.png

**Texto alternativo:** Pieza de Moira Ordo sobre diseño: Diseñamos para quien va a usarlo.. Tus clientes. Tu equipo. Tú.

## P32 · ¿Le damos forma a tu próxima idea?

Si estás creando una web, revisando tu presencia digital o pensando en una herramienta para tu negocio, podemos empezar por una conversación.

Cuéntanos qué haces, qué te está costando hoy y qué te gustaría conseguir con el proyecto. Te ayudaremos a ordenar el siguiente paso.

Web, CRM, marca, software o juegos: elegimos la solución a partir de la necesidad.

Escríbenos a info@moiraordo.es o en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P32.png

**Texto alternativo:** Pieza de Moira Ordo sobre contacto: ¿Le damos forma a tu próxima idea?. Diseño con intención. Tecnología a medida.

## P33 · Esto es lo que ves cuando entras.

Detrás de muchas de nuestras webs hay un panel que no se ve desde fuera.

Desde él se publican productos, propiedades o servicios, se revisan las solicitudes que llegan desde la web, se preparan presupuestos y se consulta el tráfico.

Lo hemos construido nosotros y lo adaptamos a cada proyecto: cada empresa ve sus datos y los módulos que necesita.

Explora la demo en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P33.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: Esto es lo que ves cuando entras.. El panel de Moira Ordo: contenido, operativa y datos en un mismo lugar.

## P34 · Un vistazo al CRM por dentro.

Hablamos mucho de nuestro CRM. Hoy lo enseñamos.

Estas capturas son de WatchEcommerceDemo, una empresa de prueba con un catálogo de relojes: items con fotos y estado, un dashboard con el resumen de la empresa, presupuestos con respuesta del cliente y el panel adaptado al móvil.

Desliza para recorrerlo.

Pruébalo con datos ficticios en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P34/P34_01.png, 03_carruseles/P34/P34_02.png, 03_carruseles/P34/P34_03.png, 03_carruseles/P34/P34_04.png, 03_carruseles/P34/P34_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: Un vistazo al CRM por dentro.. Cinco pantallas reales de una empresa demo.

**Alt por diapositiva:**
- Diapositiva 1/5: Un recorrido por el panel.. Pantallas reales de WatchEcommerceDemo, una empresa de prueba.
- Diapositiva 2/5: Tu catálogo, a la vista.. Cada producto es un item con fotos, estado y atributos propios.
- Diapositiva 3/5: Tu negocio, de un vistazo.. El dashboard resume items, atributos, solicitudes y planning.
- Diapositiva 4/5: Presupuestos con respuesta.. El cliente acepta o rechaza desde un enlace privado.
- Diapositiva 5/5: También desde el móvil.. El panel se adapta a la pantalla pequeña. moiraordo.es/crm

## P35 · Del formulario a tu pipeline.

Cuando alguien te escribe desde la web, esa conversación no debería quedarse en una bandeja de entrada.

En nuestro CRM, las solicitudes crean contactos de forma automática. Después puedes moverlos por etapas: nuevo, contactado, visita, oferta, cerrado o perdido. Las etapas se pueden configurar.

Así sabes qué consultas están pendientes y cuál es el siguiente paso con cada una.

Mira cómo funciona en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P35.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: Del formulario a tu pipeline.. Cada solicitud de la web se convierte en un contacto con su etapa.

## P36 · Presupuestos que terminan en factura.

Un presupuesto pasa por varias manos: se prepara, se envía, se espera la respuesta y, si sale bien, se factura.

En el módulo de presupuestos del CRM ves de un vistazo lo aceptado, lo pendiente y los borradores. Cuando el cliente acepta, el presupuesto se puede convertir en factura sin volver a escribir los datos.

Menos copiar y pegar. Más tiempo para el trabajo.

Descubre los módulos en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P36.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: Presupuestos que terminan en factura.. Crear, enviar, recibir la respuesta y facturar desde el mismo panel.

## P37 · Analítica sin cookies.

Saber qué páginas se visitan ayuda a decidir qué mejorar.

El CRM incluye una analítica propia que mide el tráfico y los eventos de clic de tu web sin cookies. Puedes consultar los últimos 7, 30 o 90 días junto al resto de la información de tu empresa.

La captura es del panel de Regia Mare.

Conoce el CRM en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P37.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: Analítica sin cookies.. Visitantes, páginas vistas y eventos de clic de tu web, en tu panel.

## P38 · Un panel, varias empresas.

El mismo CRM da servicio a negocios muy distintos: una inmobiliaria, una empresa de reformas, un servicio de transfers o una tienda de relojes de prueba.

Cada empresa tiene su espacio, sus usuarios con su rol y solo los módulos que necesita. Si mañana necesitas presupuestos o planning, se activan sin cambiar de herramienta.

Cuéntanos cómo trabajas: moiraordo.es/contacto.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P38.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: Un panel, varias empresas.. Cada cliente con sus datos, sus usuarios y sus módulos.

## P39 · SEO en cada ficha.

Cada producto, propiedad o servicio puede tener su propio título y descripción para buscadores y redes.

En la ficha de cada item del CRM hay un apartado de SEO con vista previa. Si no sabes por dónde empezar, una propuesta automática usa el título y el resumen del item, sin IA ni servicios externos. Después puedes ajustarla.

Pequeños detalles que suman cuando el catálogo crece.

Explora la demo en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P39.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: SEO en cada ficha.. Título, descripción y vista previa para buscadores, item a item.

## P40 · Lo que más nos preguntan del CRM.

¿Necesito saber programar? No. El panel está pensado para quien gestiona el negocio.

¿Se adapta a lo que hago? Sí: activamos los módulos que tienen sentido para tu proyecto y dejamos fuera el resto.

¿Puedo verlo antes? Sí. La demo pública tiene datos ficticios y puedes navegar libremente sin guardar nada.

¿Tienes otra pregunta? Déjala en comentarios.

Prueba la demo en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P40.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: Lo que más nos preguntan del CRM.. Tres respuestas cortas antes de empezar.

## P41 · Arquelia, de cerca.

Arquelia hace reformas integrales de alta gama en Barcelona y Cataluña. Su web tenía que transmitir ese nivel desde la primera imagen.

Trabajamos una presentación editorial: fotografía a pantalla completa, servicios bien separados y una llamada clara para pedir presupuesto. El contenido está conectado a nuestro CRM y el proyecto incluye marketing online.

Desliza para recorrerla.

Visítala en arquelia.es.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 03_carruseles/P41/P41_01.png, 03_carruseles/P41/P41_02.png, 03_carruseles/P41/P41_03.png, 03_carruseles/P41/P41_04.png, 03_carruseles/P41/P41_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Arquelia, de cerca.. Una web de reformas de alta gama con el trabajo como protagonista.

**Alt por diapositiva:**
- Diapositiva 1/5: Arquelia, de cerca.. Una web de reformas de alta gama con el trabajo como protagonista.
- Diapositiva 2/5: Primera impresión.. Fotografía a pantalla completa y un mensaje directo.
- Diapositiva 3/5: Igual de cuidada en el móvil.. La misma presencia editorial, adaptada a la pantalla pequeña.
- Diapositiva 4/5: Servicios claros.. Cocina, baños, reforma integral y rehabilitación, cada uno en su sitio.
- Diapositiva 5/5: Visítala en arquelia.es.. Diseño, desarrollo, CRM y marketing online de Moira Ordo.

## P42 · Regia Mare, en todas las pantallas.

Quien busca vivienda mira propiedades en el ordenador de casa y en el móvil de camino al trabajo. La web tiene que funcionar igual de bien en los dos sitios.

Regia Mare presenta su catálogo con fichas claras, filtros y tres idiomas. Detrás, el equipo gestiona cada propiedad desde nuestro CRM.

Una web a medida para una inmobiliaria con identidad propia.

Descubre el proyecto en regiamare.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P42.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Regia Mare, en todas las pantallas.. Catálogo inmobiliario multidioma para Barcelona y la Costa Dorada.

## P43 · Regia Mare, por dentro.

Una web inmobiliaria tiene dos públicos: quien busca casa y el equipo que publica las propiedades.

En Regia Mare cuidamos los dos lados. Fuera, fichas con foto, precio, habitaciones y metros, y una identidad cálida y reconocible. Dentro, un panel donde dar de alta, editar o archivar propiedades sin tocar el código.

Desliza para ver el recorrido completo.

Explora regiamare.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 03_carruseles/P43/P43_01.png, 03_carruseles/P43/P43_02.png, 03_carruseles/P43/P43_03.png, 03_carruseles/P43/P43_04.png, 03_carruseles/P43/P43_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Regia Mare, por dentro.. Cómo se presenta una inmobiliaria cuando cada propiedad cuenta.

**Alt por diapositiva:**
- Diapositiva 1/5: Regia Mare, por dentro.. Cómo se presenta una inmobiliaria cuando cada propiedad cuenta.
- Diapositiva 2/5: Propiedades destacadas.. Foto, precio, habitaciones y metros a primera vista.
- Diapositiva 3/5: Fichas que caben en el móvil.. La información clave sigue visible en la pantalla pequeña.
- Diapositiva 4/5: Una marca con carácter.. Color, tipografía y detalles al servicio de su identidad.
- Diapositiva 5/5: Y detrás, el CRM.. El equipo publica y actualiza propiedades desde el panel. regiamare.com

## P44 · Reservar un chófer, sin rodeos.

En una web de reservas, cada paso de más es una oportunidad para abandonar.

En Vemaro Transfers, el formulario está en la primera pantalla del móvil: origen, destino, fecha y pasajeros. Después llega un precio cerrado, con IVA y peajes incluidos, y el pago integrado.

Detrás hay una plataforma a medida para gestionar flota, chóferes y servicios.

Pruébala en vemarotransfers.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P44.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Reservar un chófer, sin rodeos.. Vemaro Transfers · Origen, destino, fecha y pasajeros en la primera pantalla.

## P45 · Vemaro, de la web a la reserva.

Vemaro Transfers ofrece traslados con chófer privado desde Barcelona. La web no solo presenta el servicio: permite reservarlo.

Trabajamos una experiencia de reserva directa, una explicación en tres pasos y una sección para servicios a medida como bodas, eventos o viajes de varios días. Todo conectado con la plataforma que gestiona la operativa.

Desliza para recorrer el proyecto.

Conoce el proyecto en vemarotransfers.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 03_carruseles/P45/P45_01.png, 03_carruseles/P45/P45_02.png, 03_carruseles/P45/P45_03.png, 03_carruseles/P45/P45_04.png, 03_carruseles/P45/P45_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Vemaro, de la web a la reserva.. Un servicio de chófer privado con reserva online y gestión propia.

**Alt por diapositiva:**
- Diapositiva 1/5: Vemaro, de la web a la reserva.. Un servicio de chófer privado con reserva online y gestión propia.
- Diapositiva 2/5: Reservar en minutos.. El formulario de reserva está en la primera pantalla.
- Diapositiva 3/5: Tres pasos, sin sorpresas.. Cuéntanos tu trayecto, elige tu vehículo, paga y listo.
- Diapositiva 4/5: También a medida.. Bodas, eventos, chófer por días y varias paradas.
- Diapositiva 5/5: Y en el móvil, igual de fácil.. Visítala en vemarotransfers.com

## P46 · MatchRise, un manager en tu móvil.

MatchRise empieza en Sexta División, con un club modesto y cinco estrellas de reputación. Cada derrota cuesta una.

El jugador elige su club, define el plan de temporada con la directiva, decide el estilo de juego y la política de plantilla, y gestiona lo que pasa entre partido y partido.

Un juego HTML5 diseñado y desarrollado por Moira Ordo Games. Desliza para verlo.

Juega en matchrise.es.

#JuegosHTML5 #DesarrolloDeJuegos #MoiraOrdoGames #MoiraOrdo

**Archivos:** 03_carruseles/P46/P46_01.png, 03_carruseles/P46/P46_02.png, 03_carruseles/P46/P46_03.png, 03_carruseles/P46/P46_04.png, 03_carruseles/P46/P46_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre games: MatchRise, un manager en tu móvil.. Fútbol por rondas desde el navegador.

**Alt por diapositiva:**
- Diapositiva 1/5: MatchRise, un manager en tu móvil.. Fútbol por rondas desde el navegador.
- Diapositiva 2/5: Elige cómo jugar.. Nueva carrera, legado simulado o Copa Mundial de Naciones.
- Diapositiva 3/5: Empieza desde abajo.. Sexta División y un club modesto. De eso va.
- Diapositiva 4/5: Decide cada temporada.. Ambición, estilo de juego y política de plantilla.
- Diapositiva 5/5: Juégalo en matchrise.es.. Diseño y desarrollo de Moira Ordo Games.

## P47 · Cuatro proyectos. Cuatro formas de trabajar.

Una empresa de reformas que necesita enseñar su trabajo. Una inmobiliaria con un catálogo que cambia cada semana. Un servicio de chófer privado que vende reservas. Un juego de fútbol para el navegador.

Cuatro proyectos muy distintos, cuatro webs diseñadas y desarrolladas a medida por el mismo equipo.

¿Cuál quieres que te contemos en detalle?

Explora el portfolio en moiraordo.es/proyectos.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P47.png

**Texto alternativo:** Pieza de Moira Ordo sobre portfolio: Cuatro proyectos. Cuatro formas de trabajar.. Arquelia · Regia Mare · Vemaro Transfers · MatchRise

## P48 · Reformas que se ven como son.

En reformas de alta gama, la fotografía hace gran parte del trabajo. La web tiene que dejarla respirar.

Para Arquelia diseñamos una página donde las imágenes ocupan la pantalla, los servicios se entienden de un vistazo y pedir presupuesto está siempre a mano, también desde el móvil.

Puedes recorrerla en arquelia.es.

Explora el proyecto en arquelia.es.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P48.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Reformas que se ven como son.. Arquelia · Fotografía, servicios y contacto en una web editorial.

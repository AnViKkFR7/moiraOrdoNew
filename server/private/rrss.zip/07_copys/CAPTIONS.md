# Textos de las 32 publicaciones

Cada bloque corresponde a los archivos con el mismo ID. Copia el caption sin el título editorial.

## P01 · Tu web. Tu contenido. Tu control.

Una web debería parecerse a tu negocio. Y deberías poder actualizarla sin pedir ayuda para cada cambio.

En Moira Ordo unimos diseño, desarrollo y un CRM propio: cuidamos cómo se ve tu web y cómo la gestionas después. Si además necesitas SEO o publicidad, el mismo equipo puede acompañarte.

Empezamos por entender qué haces y a quién quieres llegar.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P01.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Tu web. Tu contenido. Tu control.. Diseño a medida + CRM + un equipo que te acompaña.

## P02 · ¿Qué podemos hacer por ti?

Cuando tu web, tu contenido y tu marketing van por separado, aparecen las tareas repetidas y las conversaciones que no llegan a ninguna parte.

Podemos ayudarte con diseño web, desarrollo, marca, CRM, software a medida y juegos HTML5. También trabajamos el SEO y la publicidad cuando el proyecto lo necesita.

Desliza para ver cómo encajan las piezas.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P02/P02_01.png, 03_carruseles/P02/P02_02.png, 03_carruseles/P02/P02_03.png, 03_carruseles/P02/P02_04.png, 03_carruseles/P02/P02_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre servicios: ¿Qué podemos hacer por ti?. Un equipo para conectar las piezas de tu presencia digital.

**Alt por diapositiva:**
- Diapositiva 1/5: ¿Qué podemos hacer por ti?. Web, contenido y herramientas que trabajan juntos.
- Diapositiva 2/5: Una web con identidad.. Estructura, tipografía y diseño pensados para tu marca y para quien te visita.
- Diapositiva 3/5: Contenido que gestionas tú.. Textos, imágenes y catálogo desde un panel. El diseño conserva su coherencia.
- Diapositiva 4/5: Más allá del lanzamiento.. SEO, publicidad, mantenimiento y nuevas funciones según las necesidades del proyecto.
- Diapositiva 5/5: Hablemos de tu negocio.. Cuéntanos qué haces, qué necesitas y qué te gustaría mejorar. moiraordo.es/contacto

## P03 · Una web para abrir puertas.

En una inmobiliaria, el catálogo cambia y cada vivienda necesita contarse bien.

Para Regia Mare trabajamos una web a medida, multidioma y conectada a nuestro CRM. Las propiedades se presentan con fichas, atributos y filtros que ayudan a recorrer la oferta.

Una forma de conectar la presentación de cada inmueble con el trabajo diario del equipo.

Explora el proyecto: regiamare.com

Descubre el proyecto en regiamare.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P03.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Una web para abrir puertas.. Regia Mare · Catálogo inmobiliario y diseño a medida.

## P04 · Bonita, sí. Útil, también.

El diseño importa. También importa que una persona encuentre lo que busca.

Por eso trabajamos la jerarquía, la navegación, los textos y la versión móvil junto a la parte visual. Una buena primera impresión tiene que continuar con una experiencia clara.

Piensa en tu web: ¿qué debería poder hacer alguien en su primera visita?

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P04.png

**Texto alternativo:** Pieza de Moira Ordo sobre diseño: Bonita, sí. Útil, también.. Una buena web ayuda a entender, decidir y contactar.

## P05 · ¿Tu web lo pone fácil?

Abre tu web desde el móvil y mírala como si no conocieras tu negocio.

1. ¿Se entiende qué haces?
2. ¿Se encuentra un ejemplo de tu trabajo?
3. ¿Está claro cómo contactar?

No es una auditoría completa, pero sí una buena primera revisión. Si alguna respuesta cuesta, puede haber una oportunidad de mejora.

Guárdalo y revisa tu web con estas tres preguntas.

#ConsejosWeb #ExperienciaDeUsuario #WebParaNegocios #MoiraOrdo

**Archivos:** 02_posts/P05.png

**Texto alternativo:** Pieza de Moira Ordo sobre educación: ¿Tu web lo pone fácil?. Tres preguntas que ayudan a detectar fricción.

## P06 · El diseño empieza antes del diseño.

Antes de elegir colores, necesitamos entender el negocio.

Qué ofreces, quién te visita, qué dudas tiene y qué debería ocurrir después de entrar en la web. Con esa base definimos estructura, diseño y desarrollo.

Así trabajamos en Moira Ordo. Desliza para recorrer el proceso.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P06/P06_01.png, 03_carruseles/P06/P06_02.png, 03_carruseles/P06/P06_03.png, 03_carruseles/P06/P06_04.png, 03_carruseles/P06/P06_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre proceso: El diseño empieza antes del diseño.. Así damos forma a una web a medida.

**Alt por diapositiva:**
- Diapositiva 1/5: Primero, escuchar.. Qué hace tu negocio, quién es tu público y qué necesita resolver tu web.
- Diapositiva 2/5: Después, ordenar.. Definimos páginas, contenido y recorridos antes de diseñar pantallas.
- Diapositiva 3/5: Dar forma a tu identidad.. Trabajamos el diseño para escritorio, tablet y móvil como un mismo sistema.
- Diapositiva 4/5: Construir y comprobar.. Convertimos el diseño en una web y revisamos sus recorridos y funciones.
- Diapositiva 5/5: Publicar y acompañar.. Te enseñamos a gestionar el contenido y acordamos cómo seguir cuidando el proyecto.

## P07 · El trabajo bien hecho merece verse.

Una web de arquitectura y reformas necesita dar espacio al trabajo: imágenes, detalles y proyectos que cuentan una forma de hacer las cosas.

Arquelia reúne un diseño editorial a medida y contenido conectado a nuestro CRM. El proyecto también incluye trabajo de marketing online y publicidad.

Aquí compartimos una imagen utilizada en el portfolio de Moira Ordo para presentar el proyecto.

Puedes recorrerla en arquelia.es.

Explora el proyecto en arquelia.es.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P07.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: El trabajo bien hecho merece verse.. Arquelia · Una presentación editorial de sus proyectos.

## P08 · Cambiar una foto no debería ser un proyecto.

Una nueva obra. Una imagen actualizada. Un servicio que cambia.

Tu negocio se mueve y tu web necesita poder acompañarlo. Con nuestro CRM gestionas los contenidos previstos para tu proyecto desde un panel, sin editar el código de la web.

El contenido cambia; la identidad visual mantiene su orden.

Explora la demo en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P08.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: Cambiar una foto no debería ser un proyecto.. Tu contenido, desde un panel.

## P09 · Todo empieza con una buena conversación.

No hace falta llegar con un documento perfecto.

Nos ayuda saber qué hace tu negocio, qué te gustaría mejorar y qué herramientas utilizas hoy. A partir de ahí podemos definir prioridades y un alcance que tenga sentido.

La primera conversación sirve para entendernos.

Cuéntanos en qué estás trabajando: moiraordo.es/contacto.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P09.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Todo empieza con una buena conversación.. Escuchamos lo que necesitas antes de proponerte una solución.

## P10 · Una web clara desde el móvil.

La versión móvil merece una revisión propia. No basta con que los bloques quepan.

Hay que leer, navegar, tocar botones y completar formularios en una pantalla pequeña. En este carrusel repasamos decisiones que ayudan a que ese recorrido sea más sencillo.

¿Cuál revisarías primero en tu web?

Guárdalo para tu próxima revisión.

#ConsejosWeb #ExperienciaDeUsuario #WebParaNegocios #MoiraOrdo

**Archivos:** 03_carruseles/P10/P10_01.png, 03_carruseles/P10/P10_02.png, 03_carruseles/P10/P10_03.png, 03_carruseles/P10/P10_04.png, 03_carruseles/P10/P10_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre educación: Una web clara desde el móvil.. Cinco ideas para revisar tu experiencia móvil.

**Alt por diapositiva:**
- Diapositiva 1/5: Tu web, en pequeño.. ¿Se sigue entendiendo igual de bien cuando la abres desde el móvil?
- Diapositiva 2/5: Texto que se pueda leer.. Tamaño, contraste y párrafos que no conviertan la lectura en un esfuerzo.
- Diapositiva 3/5: Botones que se puedan tocar.. Acciones visibles, espacio alrededor y nombres que expliquen qué ocurrirá.
- Diapositiva 4/5: Formularios sin rodeos.. Pide lo que necesitas y explica qué campo falta cuando hay un error.
- Diapositiva 5/5: Pruébala como un cliente.. Abre un servicio, busca un ejemplo y envía una consulta de prueba con tu equipo.

## P11 · Proyectos nuevos. Contenido al día.

El portfolio de una empresa de reformas no se queda quieto. Cada proyecto terminado añade una nueva historia que mostrar.

Navagli cuenta con una web corporativa conectada a nuestro CRM para gestionar contenido y presentar su trabajo.

Diseñamos la web pensando también en las personas que la actualizarán después.

Conoce el proyecto: navagli.com.

Mira la web en navagli.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P11.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Proyectos nuevos. Contenido al día.. Navagli · Web corporativa conectada al CRM.

## P12 · Diseño con intención. Tecnología a medida.

Que una web se vea bien y que funcione bien forman parte del mismo trabajo.

En Moira Ordo conectamos la identidad visual con la estructura, el desarrollo y la gestión del contenido. El objetivo es construir una base que puedas usar y seguir ampliando.

Diseño con intención. Tecnología a medida.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P12.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Diseño con intención. Tecnología a medida.. Dos formas de cuidar el mismo proyecto.

## P13 · ¿Tu equipo trabaja con las mismas piezas?

Cuando una consulta entra por la web, el trabajo no termina en el formulario. Hay que revisar el contacto, darle seguimiento y organizar lo que viene después.

Nuestro panel reúne contenido, solicitudes, contactos, planning, presupuestos y facturación, con acceso por empresa y rol. La configuración se adapta a los módulos de cada proyecto.

La demo pública permite explorar estas áreas con datos ficticios.

Pruébala en moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P13.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: ¿Tu equipo trabaja con las mismas piezas?. Contenido, contactos y documentos en un mismo panel.

## P14 · De visita a conversación.

¿Qué necesita saber alguien antes de escribirte?

Una propuesta clara, ejemplos de tu trabajo y una forma sencilla de contactar pueden ayudar a que la conversación empiece con contexto.

No hay un botón mágico: hay decisiones de contenido y diseño que merece la pena cuidar.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#ConsejosWeb #ExperienciaDeUsuario #WebParaNegocios #MoiraOrdo

**Archivos:** 03_carruseles/P14/P14_01.png, 03_carruseles/P14/P14_02.png, 03_carruseles/P14/P14_03.png, 03_carruseles/P14/P14_04.png, 03_carruseles/P14/P14_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre educación: De visita a conversación.. Un recorrido claro importa más que añadir botones.

**Alt por diapositiva:**
- Diapositiva 1/5: De visita a conversación.. Una web conecta lo que ofreces con lo que la persona necesita entender.
- Diapositiva 2/5: Explica qué resuelves.. Presenta tu servicio con palabras que utilice tu cliente, sin esconder lo importante.
- Diapositiva 3/5: Enseña tu trabajo.. Un proyecto real aporta contexto: qué era necesario y qué se construyó.
- Diapositiva 4/5: Invita a dar el paso.. Una llamada a la acción concreta y un formulario claro facilitan el contacto.
- Diapositiva 5/5: Cuida lo que pasa después.. Revisa las solicitudes, prepara la respuesta y mantén el seguimiento.

## P15 · Del trayecto a la reserva.

Hay negocios que necesitan algo más que una web de presentación.

Vemaro Transfers conecta una experiencia de reserva con una plataforma para gestionar flota, chóferes y servicios. El frontal incorpora presupuesto y pagos integrados.

Es un ejemplo de cómo un proyecto digital puede formar parte de la operativa de una empresa.

Descúbrelo en vemarotransfers.com.

Conoce el proyecto en vemarotransfers.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P15.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Del trayecto a la reserva.. Vemaro Transfers · Plataforma y gestión a medida.

## P16 · Una marca se reconoce en los detalles.

La identidad de tu negocio no termina en el logotipo.

Está en cómo se leen tus mensajes, cómo se ordenan las páginas y qué relación tienen las imágenes, los colores y la tipografía.

También diseñamos identidades de marca para que tu web y tus materiales compartan una base visual coherente.

¿Estás creando o revisando tu marca? Hablemos.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P16.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Una marca se reconoce en los detalles.. Logo, tipografía, color y una forma coherente de presentarte.

## P17 · Que te vean. Que te entiendan. Que te escriban.

Una web publicada necesita encontrar su lugar.

El SEO trabaja cómo se presenta y se encuentra tu contenido. La publicidad permite impulsar campañas concretas. El diseño y los textos ayudan a que la visita entienda tu propuesta.

En Moira Ordo podemos trabajar estas piezas con el mismo equipo, definiendo objetivos y revisando los datos sin prometer resultados automáticos.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#MarketingDigital #SEOLocal #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P17.png

**Texto alternativo:** Pieza de Moira Ordo sobre marketing: Que te vean. Que te entiendan. Que te escriban.. SEO, contenido y publicidad con un objetivo compartido.

## P18 · Antes de pedir una web.

Para empezar no necesitas conocer la tecnología. Sí ayuda compartir qué esperas del proyecto.

Este pequeño briefing sirve para ordenar la conversación: objetivo, público, contenido y gestión. Podemos ayudarte a concretarlo si todavía no lo tienes claro.

Guarda esta guía o úsala para escribirnos.

#ConsejosWeb #ExperienciaDeUsuario #WebParaNegocios #MoiraOrdo

**Archivos:** 03_carruseles/P18/P18_01.png, 03_carruseles/P18/P18_02.png, 03_carruseles/P18/P18_03.png, 03_carruseles/P18/P18_04.png, 03_carruseles/P18/P18_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre educación: Antes de pedir una web.. Lo que conviene poner sobre la mesa.

**Alt por diapositiva:**
- Diapositiva 1/5: Antes de pedir una web.. Cuatro preguntas para que la primera conversación sea más útil.
- Diapositiva 2/5: ¿Qué debe conseguir?. Presentar tus servicios, mostrar proyectos, recibir consultas o gestionar reservas.
- Diapositiva 3/5: ¿A quién va dirigida?. Quién te visita, qué busca y qué necesita saber para dar el siguiente paso.
- Diapositiva 4/5: ¿Qué contenido y gestión necesitas?. Textos, imágenes, catálogo, idiomas y personas que actualizarán la web.
- Diapositiva 5/5: ¿Qué es prioritario ahora?. Pongamos en orden alcance, presupuesto y fases. moiraordo.es/contacto

## P19 · Una forma clara de pedir presupuesto.

Para una empresa de reformas, una web puede ayudar a explicar servicios, mostrar trabajo y facilitar una primera consulta.

En Reformas Llobregat trabajamos una web orientada al contacto, junto con SEO local y publicidad.

La pieza muestra su diseño; las cifras de resultados necesitan su propia medición y contexto.

Recorre el proyecto en reformasllobregat.com.

Descubre reformasllobregat.com.

#DiseñoWeb #DesarrolloWeb #PortfolioWeb #MoiraOrdo

**Archivos:** 02_posts/P19.png

**Texto alternativo:** Pieza de Moira Ordo sobre proyecto: Una forma clara de pedir presupuesto.. Reformas Llobregat · Web, SEO local y publicidad.

## P20 · Un equipo. Tres miradas.

Lo digital se construye con distintas miradas.

Aaron trabaja la arquitectura, el desarrollo y las integraciones. Joselyn conecta diseño, frontend y acompañamiento al cliente. Fede se ocupa de marketing, SEO y publicidad.

Un equipo que puede acompañarte desde la primera idea hasta la evolución del proyecto.

Conócenos en moiraordo.es/#equipo.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P20.png

**Texto alternativo:** Pieza de Moira Ordo sobre equipo: Un equipo. Tres miradas.. Diseño, desarrollo y marketing alrededor de tu negocio.

## P21 · La web cambia. Tu identidad se mantiene.

Hay una diferencia entre actualizar contenido y tener que rediseñar una página cada vez.

En nuestro sistema, el panel gestiona los datos y la web los presenta siguiendo el diseño del proyecto. Puedes renovar los contenidos previstos sin entrar en el código.

Así damos espacio a que el negocio cambie sin perder su coherencia visual.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P21.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: La web cambia. Tu identidad se mantiene.. Contenido flexible sobre un diseño cuidado.

## P22 · ¿Qué puede vivir en tu CRM?

No todos los negocios necesitan las mismas herramientas. Por eso miramos primero cómo trabajas.

Contenido, contactos, agenda y documentos pueden convivir en un mismo panel con roles y empresas diferenciadas. En la demo pública puedes explorar estas áreas sin modificar datos reales.

Desliza para conocer algunas posibilidades.

Explora la demo: moiraordo.es/crm.

#CRM #GestionDeContenidos #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P22/P22_01.png, 03_carruseles/P22/P22_02.png, 03_carruseles/P22/P22_03.png, 03_carruseles/P22/P22_04.png, 03_carruseles/P22/P22_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre crm: ¿Qué puede vivir en tu CRM?. Un vistazo al panel de Moira Ordo.

**Alt por diapositiva:**
- Diapositiva 1/5: Un panel para tu negocio.. La demo de Moira Ordo reúne ejemplos de gestión en un mismo lugar.
- Diapositiva 2/5: Tu contenido al día.. Items, imágenes y atributos para presentar los elementos de cada empresa.
- Diapositiva 3/5: Conversaciones con seguimiento.. Solicitudes y contactos con responsables, etapas y actividad.
- Diapositiva 4/5: Agenda y documentos.. Planning, presupuestos y facturación según los módulos del proyecto.
- Diapositiva 5/5: Cotillea la demo.. Datos ficticios y navegación libre. Nada se guarda. moiraordo.es/crm

## P23 · También construimos formas de jugar.

Además de webs y software, creamos experiencias jugables para navegador.

MusiBingo es un bingo musical para jugar en grupo. MatchRise es un manager de fútbol por rondas. Dos proyectos distintos que se abren con un enlace.

También podemos plantear juegos a medida para marcas, eventos o campañas.

Descubre MusiBingo en musibingo.com.

#JuegosHTML5 #DesarrolloDeJuegos #MoiraOrdoGames #MoiraOrdo

**Archivos:** 02_posts/P23.png

**Texto alternativo:** Pieza de Moira Ordo sobre games: También construimos formas de jugar.. Moira Ordo Games · Juegos HTML5 para navegador.

## P24 · Lo importante también está detrás.

Lo que se ve es solo una parte de una web.

También están la estructura del contenido, las integraciones y las decisiones que harán más sencillo ampliar el proyecto.

Trabajamos diseño y desarrollo juntos para que las funciones tengan sentido para tu negocio y la base se pueda seguir cuidando.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P24.png

**Texto alternativo:** Pieza de Moira Ordo sobre desarrollo: Lo importante también está detrás.. Estructura, mantenimiento y una base para seguir creciendo.

## P25 · Tu negocio no cabe en una plantilla.

Un estudio, una inmobiliaria y un servicio de transfers trabajan de formas distintas.

Sus webs también necesitan resolver cosas diferentes: presentar proyectos, explorar un catálogo o reservar un servicio.

El punto de partida en Moira Ordo es entender ese contexto y diseñar una solución con sentido.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#IdentidadDeMarca #DiseñoWeb #NegociosDigitales #MoiraOrdo

**Archivos:** 02_posts/P25.png

**Texto alternativo:** Pieza de Moira Ordo sobre marca: Tu negocio no cabe en una plantilla.. Empezamos por tus necesidades, no por un catálogo de pantallas.

## P26 · Una web no termina al publicarla.

Publicar abre una nueva etapa.

Revisar el contenido, comprobar el contacto, cuidar el mantenimiento y decidir qué mejorar forma parte de mantener viva una presencia digital.

El acompañamiento se define según lo que necesite cada proyecto: merece la pena hablarlo desde el principio.

Guárdalo para tu próximo lanzamiento.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P26/P26_01.png, 03_carruseles/P26/P26_02.png, 03_carruseles/P26/P26_03.png, 03_carruseles/P26/P26_04.png, 03_carruseles/P26/P26_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre proceso: Una web no termina al publicarla.. Qué conviene cuidar después del lanzamiento.

**Alt por diapositiva:**
- Diapositiva 1/5: Publicar es solo el comienzo.. Tu web necesita acompañar a un negocio que sigue cambiando.
- Diapositiva 2/5: Contenido que sigue vigente.. Servicios, proyectos y datos de contacto revisados con cierta frecuencia.
- Diapositiva 3/5: Recorridos que funcionan.. Comprueba desde el móvil que la navegación y el contacto siguen siendo claros.
- Diapositiva 4/5: Revisar para mejorar.. Lee las consultas y los datos disponibles antes de decidir el siguiente cambio.
- Diapositiva 5/5: Un siguiente paso con sentido.. Acordamos mantenimiento, soporte y nuevas fases según lo que necesites.

## P27 · Construye. Adapta. Asciende.

Cada producto digital tiene su propio recorrido. También un juego.

En MatchRise, un manager de fútbol por rondas, el jugador toma decisiones sobre plantilla, formación y partido para avanzar entre divisiones.

Es otro de los proyectos de Moira Ordo Games: diseño y desarrollo al servicio de una experiencia jugable.

Puedes verlo en matchrise.es.

Conoce MatchRise en matchrise.es.

#JuegosHTML5 #DesarrolloDeJuegos #MoiraOrdoGames #MoiraOrdo

**Archivos:** 02_posts/P27.png

**Texto alternativo:** Pieza de Moira Ordo sobre games: Construye. Adapta. Asciende.. MatchRise · Un manager de fútbol que vive en el navegador.

## P28 · Tu proyecto, paso a paso.

No hace falta resolverlo todo el primer día.

Trabajamos por pasos: entender la necesidad, definir una estructura, diseñar, construir y revisar. Eso nos permite ordenar prioridades y conversar sobre decisiones concretas.

¿Tienes una idea que todavía no sabes cómo aterrizar?

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P28.png

**Texto alternativo:** Pieza de Moira Ordo sobre proceso: Tu proyecto, paso a paso.. Escuchar. Diseñar. Construir. Acompañar.

## P29 · ¿Qué debería resolver tu próxima web?

Quizá necesitas mostrar mejor tus proyectos. O recibir consultas con más contexto. O gestionar un catálogo que hoy te cuesta mantener al día.

Antes de hablar de pantallas, hablemos de ese trabajo.

Cuéntanos en comentarios qué debería resolver tu próxima web. Si prefieres hablar de tu caso en privado, puedes escribirnos.

Te leemos. moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P29.png

**Texto alternativo:** Pieza de Moira Ordo sobre conversación: ¿Qué debería resolver tu próxima web?. Una pregunta más útil que empezar por los colores.

## P30 · Hecho para negocios reales.

Una parte de nuestro portfolio, en una sola idea: cada negocio necesita una solución propia.

Regia Mare, Arquelia, Navagli, Reformas Llobregat y Vemaro Transfers son proyectos con recorridos y prioridades diferentes.

En moiraordo.es/proyectos puedes ver cómo se traduce ese contexto en diseño y funciones.

Explora el portfolio en moiraordo.es/proyectos.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 03_carruseles/P30/P30_01.png, 03_carruseles/P30/P30_02.png, 03_carruseles/P30/P30_03.png, 03_carruseles/P30/P30_04.png, 03_carruseles/P30/P30_05.png

**Texto alternativo:** Pieza de Moira Ordo sobre portfolio: Hecho para negocios reales.. Webs, plataformas y experiencias con necesidades distintas.

**Alt por diapositiva:**
- Diapositiva 1/5: Hecho para negocios reales.. Una selección de nuestro portfolio. Cada proyecto parte de una necesidad distinta.
- Diapositiva 2/5: Regia Mare.. Catálogo inmobiliario, diseño a medida y contenido conectado al CRM.
- Diapositiva 3/5: Arquelia.. Diseño editorial y contenido para presentar sus proyectos. Imagen de nuestro portfolio.
- Diapositiva 4/5: Vemaro Transfers.. Reservas y plataforma de gestión para una empresa de transfers privados.
- Diapositiva 5/5: ¿Y el próximo proyecto?. Podría empezar con una conversación sobre tu negocio. moiraordo.es/contacto

## P31 · Diseñamos para quien va a usarlo.

Una web tiene más de una persona al otro lado.

Está quien entra para conocer tu negocio. Está quien necesita contactar. Y está el equipo que después publicará contenido o revisará las solicitudes.

Diseñamos pensando en esos recorridos, para que la experiencia tenga sentido a ambos lados.

Cuéntanos tu proyecto en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P31.png

**Texto alternativo:** Pieza de Moira Ordo sobre diseño: Diseñamos para quien va a usarlo.. Tus clientes. Tu equipo. Tú.

## P32 · ¿Le damos forma a tu próxima idea?

Si estás creando una web, revisando tu presencia digital o pensando en una herramienta para tu negocio, podemos empezar por una conversación.

Cuéntanos qué haces, qué te está costando hoy y qué te gustaría conseguir con el proyecto. Te ayudaremos a ordenar el siguiente paso.

Web, CRM, marca, software o juegos: elegimos la solución a partir de la necesidad.

Escríbenos a info@moiraordo.es o en moiraordo.es/contacto.

#DiseñoWeb #DesarrolloWeb #WebParaEmpresas #MoiraOrdo

**Archivos:** 02_posts/P32.png

**Texto alternativo:** Pieza de Moira Ordo sobre contacto: ¿Le damos forma a tu próxima idea?. Diseño con intención. Tecnología a medida.

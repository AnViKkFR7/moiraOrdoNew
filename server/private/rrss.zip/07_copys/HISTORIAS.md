# Historias: qué subir y qué añadir en Instagram

Las imágenes son estáticas. Las encuestas, preguntas y enlaces indicados se añaden como stickers nativos.

## S01 · Hola, somos Moira Ordo.
Archivo: `04_historias/S01.png`

Presentación inicial. Publicar sin sticker.

Alt/descripción: Hola, somos Moira Ordo.. Diseñamos webs a medida y las conectamos a un CRM que gestionas tú.

## S02 · ¿Tu web te representa?
Archivo: `04_historias/S02.png`

Añadir encuesta nativa: Sí / Necesita un cambio.

Alt/descripción: ¿Tu web te representa?. ¿Se parece a cómo trabaja tu negocio hoy?

## S03 · Regia Mare.
Archivo: `04_historias/S03.png`

Añadir enlace a https://regiamare.com/

Alt/descripción: Regia Mare.. Una web para explorar propiedades, con catálogo y filtros.

## S04 · Tu contenido. Tu control.
Archivo: `04_historias/S04.png`

Añadir enlace a https://moiraordo.es/crm

Alt/descripción: Tu contenido. Tu control.. Explora nuestra demo con datos ficticios.

## S05 · ¿Se entiende qué haces?
Archivo: `04_historias/S05.png`

Consejo de revisión. Sin sticker.

Alt/descripción: ¿Se entiende qué haces?. Abre tu web y mira el primer bloque como si fueras un cliente.

## S06 · Antes de diseñar, escuchamos.
Archivo: `04_historias/S06.png`

Añadir preguntas: ¿Qué debería resolver tu web?

Alt/descripción: Antes de diseñar, escuchamos.. Negocio, público y objetivos: las primeras piezas.

## S07 · Arquelia.
Archivo: `04_historias/S07.png`

Añadir enlace a https://arquelia.es/

Alt/descripción: Arquelia.. Diseño editorial para mostrar proyectos con detalle.

## S08 · Una web bonita y fácil de usar.
Archivo: `04_historias/S08.png`

Añadir encuesta: ¿Qué revisarías? Diseño / Navegación.

Alt/descripción: Una web bonita y fácil de usar.. La navegación también forma parte del diseño.

## S09 · Pequeños cambios. Sin grandes líos.
Archivo: `04_historias/S09.png`

Añadir enlace a https://moiraordo.es/crm

Alt/descripción: Pequeños cambios. Sin grandes líos.. Gestiona el contenido previsto para tu web desde un panel.

## S10 · Hagamos una prueba móvil.
Archivo: `04_historias/S10.png`

Acompañar con una grabación propia de navegación si se desea.

Alt/descripción: Hagamos una prueba móvil.. Busca un servicio, abre un proyecto y encuentra el contacto.

## S11 · Navagli.
Archivo: `04_historias/S11.png`

Añadir enlace a https://www.navagli.com/

Alt/descripción: Navagli.. Proyectos de reformas en una web conectada al CRM.

## S12 · ¿Qué te frena con tu web?
Archivo: `04_historias/S12.png`

Añadir preguntas: Te leemos.

Alt/descripción: ¿Qué te frena con tu web?. Queremos conocer lo que te cuesta en el día a día.

## S13 · De la web a la reserva.
Archivo: `04_historias/S13.png`

Añadir enlace a https://www.vemarotransfers.com/

Alt/descripción: De la web a la reserva.. Vemaro Transfers conecta la experiencia del cliente con la gestión.

## S14 · Tu marca tiene una voz.
Archivo: `04_historias/S14.png`

Añadir encuesta: ¿Tienes identidad definida? Sí / Todavía no.

Alt/descripción: Tu marca tiene una voz.. Logo, colores, tipografía y mensajes que van en la misma dirección.

## S15 · Diseñar. Construir. Acompañar.
Archivo: `04_historias/S15.png`

Historia de marca sin sticker.

Alt/descripción: Diseñar. Construir. Acompañar.. Las partes de un mismo proyecto.

## S16 · ¿Hablamos?
Archivo: `04_historias/S16.png`

Añadir enlace a https://moiraordo.es/contacto

Alt/descripción: ¿Hablamos?. Cuéntanos qué hace tu negocio y qué te gustaría mejorar.

## S17 · Que te encuentren. Que te entiendan.
Archivo: `04_historias/S17.png`

Compartir junto al post P17.

Alt/descripción: Que te encuentren. Que te entiendan.. SEO, contenidos y publicidad según lo que necesita tu proyecto.

## S18 · La pregunta de esta semana.
Archivo: `04_historias/S18.png`

Añadir preguntas: Tu objetivo en una frase.

Alt/descripción: La pregunta de esta semana.. ¿Qué debería conseguir tu próxima web?

## S19 · Reformas Llobregat.
Archivo: `04_historias/S19.png`

Añadir enlace a https://reformasllobregat.com/

Alt/descripción: Reformas Llobregat.. Web, SEO local y publicidad alrededor de la captación.

## S20 · Un equipo. Tres miradas.
Archivo: `04_historias/S20.png`

Añadir enlace a https://moiraordo.es/#equipo

Alt/descripción: Un equipo. Tres miradas.. Desarrollo, diseño y marketing para tu proyecto.

## S21 · Una consulta es el comienzo.
Archivo: `04_historias/S21.png`

Compartir junto al post P22.

Alt/descripción: Una consulta es el comienzo.. Después llega el seguimiento, la propuesta y la conversación.

## S22 · ¿Qué necesitas gestionar?
Archivo: `04_historias/S22.png`

Añadir preguntas: Cuéntanos cómo trabajas.

Alt/descripción: ¿Qué necesitas gestionar?. Contenido, catálogo, agenda, contactos…

## S23 · También creamos juegos.
Archivo: `04_historias/S23.png`

Añadir enlace a https://musibingo.com/

Alt/descripción: También creamos juegos.. MusiBingo: bingo musical para jugar desde el navegador.

## S24 · Tu web puede crecer.
Archivo: `04_historias/S24.png`

Añadir encuesta: ¿Qué necesitas primero? Web / Herramienta.

Alt/descripción: Tu web puede crecer.. Definimos lo prioritario y construimos una base para nuevas fases.

## S25 · Tu negocio tiene su forma de trabajar.
Archivo: `04_historias/S25.png`

Historia de posicionamiento sin sticker.

Alt/descripción: Tu negocio tiene su forma de trabajar.. Tu solución digital debería entenderla.

## S26 · Después de publicar.
Archivo: `04_historias/S26.png`

Guardar en destacada Proceso.

Alt/descripción: Después de publicar.. Revisa servicios, datos de contacto y solicitudes.

## S27 · Construye. Adapta. Asciende.
Archivo: `04_historias/S27.png`

Añadir enlace a https://www.matchrise.es/

Alt/descripción: Construye. Adapta. Asciende.. MatchRise: decisiones de fútbol por rondas, desde el navegador.

## S28 · ¿Qué quieres ver por aquí?
Archivo: `04_historias/S28.png`

Añadir encuesta: Proyectos / Consejos.

Alt/descripción: ¿Qué quieres ver por aquí?. Elegimos el próximo contenido contigo.

## S29 · ¿Tu web lo pone fácil?
Archivo: `04_historias/S29.png`

Compartir el post P05 con la función nativa de Instagram.

Alt/descripción: ¿Tu web lo pone fácil?. Vuelve al checklist y revisa tu primer bloque.

## S30 · Proyectos con nombre propio.
Archivo: `04_historias/S30.png`

Añadir enlace a https://moiraordo.es/proyectos

Alt/descripción: Proyectos con nombre propio.. Explora las webs y productos que hemos construido.

## S31 · De una idea a algo que puedes usar.
Archivo: `04_historias/S31.png`

Añadir preguntas: ¿Qué tienes en mente?

Alt/descripción: De una idea a algo que puedes usar.. Web, CRM, software y experiencias digitales.

## S32 · Tu próximo proyecto empieza hablando.
Archivo: `04_historias/S32.png`

Añadir enlace a https://moiraordo.es/contacto

Alt/descripción: Tu próximo proyecto empieza hablando.. info@moiraordo.es
moiraordo.es/contacto

## S33 · El panel, por dentro.
Archivo: `04_historias/S33.png`

Añadir enlace a https://moiraordo.es/crm

Alt/descripción: El panel, por dentro.. Contenido, contactos, presupuestos y analítica en un solo lugar.

## S34 · ¿Cuánto tiempo pierdes actualizando tu web?
Archivo: `04_historias/S34.png`

Añadir encuesta: Mucho / Casi nada.

Alt/descripción: ¿Cuánto tiempo pierdes actualizando tu web?. Sé sincero.

## S35 · Del formulario al pipeline.
Archivo: `04_historias/S35.png`

Añadir enlace a https://moiraordo.es/crm

Alt/descripción: Del formulario al pipeline.. Cada solicitud de la web crea un contacto con su etapa.

## S36 · Arquelia, en el móvil.
Archivo: `04_historias/S36.png`

Añadir enlace a https://arquelia.es/

Alt/descripción: Arquelia, en el móvil.. Reformas de alta gama, con la fotografía como protagonista.

## S37 · ¿Qué te gustaría gestionar tú?
Archivo: `04_historias/S37.png`

Añadir preguntas: Cuéntanos qué gestionas hoy a mano.

Alt/descripción: ¿Qué te gustaría gestionar tú?. Productos, reservas, contactos, presupuestos…

## S38 · Regia Mare, en el móvil.
Archivo: `04_historias/S38.png`

Añadir enlace a https://regiamare.com/

Alt/descripción: Regia Mare, en el móvil.. Catálogo inmobiliario en tres idiomas, conectado al CRM.

## S39 · Presupuesto aceptado.
Archivo: `04_historias/S39.png`

Añadir enlace a https://moiraordo.es/crm

Alt/descripción: Presupuesto aceptado.. El cliente responde desde un enlace privado y la respuesta aparece en tu panel.

## S40 · Vemaro, reserva en el móvil.
Archivo: `04_historias/S40.png`

Añadir enlace a https://www.vemarotransfers.com/

Alt/descripción: Vemaro, reserva en el móvil.. Origen, destino, fecha y precio cerrado.

## S41 · ¿Usas un CRM hoy?
Archivo: `04_historias/S41.png`

Añadir encuesta: Sí / Todavía no.

Alt/descripción: ¿Usas un CRM hoy?. Para contactos, presupuestos o tu catálogo.

## S42 · MatchRise.
Archivo: `04_historias/S42.png`

Añadir enlace a https://www.matchrise.es/

Alt/descripción: MatchRise.. Plan de temporada, estilo de juego y plantilla, desde el navegador.

## S43 · Analítica sin cookies.
Archivo: `04_historias/S43.png`

Añadir enlace a https://moiraordo.es/crm

Alt/descripción: Analítica sin cookies.. Visitas y páginas vistas de tu web, dentro del panel.

## S44 · SEO, ficha a ficha.
Archivo: `04_historias/S44.png`

Compartir junto al post P39.

Alt/descripción: SEO, ficha a ficha.. Título y descripción para buscadores en cada item.

## S45 · Cuatro webs, un equipo.
Archivo: `04_historias/S45.png`

Añadir enlace a https://moiraordo.es/proyectos

Alt/descripción: Cuatro webs, un equipo.. Arquelia, Regia Mare, Vemaro Transfers y MatchRise.

## S46 · Tu catálogo, en un panel.
Archivo: `04_historias/S46.png`

Añadir enlace a https://moiraordo.es/crm

Alt/descripción: Tu catálogo, en un panel.. Fotos, estado y atributos de cada producto.

## S47 · ¿Qué proyecto quieres ver en detalle?
Archivo: `04_historias/S47.png`

Añadir encuesta: Webs / CRM.

Alt/descripción: ¿Qué proyecto quieres ver en detalle?. Elegimos el próximo carrusel contigo.

## S48 · Cotillea la demo.
Archivo: `04_historias/S48.png`

Añadir enlace a https://moiraordo.es/crm

Alt/descripción: Cotillea la demo.. Datos ficticios, navegación libre. Nada se guarda.

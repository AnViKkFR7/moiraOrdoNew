# Instagram · Moira Ordo

Abre **00_EMPIEZA_AQUI.html** para ver las piezas, recorrer los carruseles, descargar las imágenes y copiar sus textos.

## Qué hay preparado

- 32 publicaciones: 24 posts y 8 carruseles de 5 diapositivas. 64 PNG de feed, 1080 × 1350.
- 32 historias en PNG 1080 × 1920, con una guía de preguntas, encuestas y enlaces.
- 8 guiones de reels de unos 22–27 segundos y 8 portadas 1080 × 1920. Los vídeos están pendientes de grabar y montar.
- 6 cubiertas de destacadas.
- 7 PNG de marca: 3 avatares, 2 logotipos transparentes y 2 piezas de eslogan. Además, 6 SVG vectoriales.
- Captions completos, CTA, hashtags y textos alternativos. Exportación Markdown, JSON y CSV.
- Calendario de 8 semanas, estrategia, guía de marca, propuesta de bio y banco de respuestas.
- Fuentes originales, recursos del portfolio y generador editable.

Son **117 PNG de publicación/marca**, además de las hojas de contacto y recursos de origen.

## Por dónde empezar

1. Revisa `01_marca/PERFIL_Y_BIO.html` y elige avatar y enlaces del perfil.
2. Abre `08_calendario/CALENDARIO.html`: las semanas son relativas para que puedas empezar cuando convenga.
3. Para un post, usa el archivo Pxx y el caption del mismo ID en `07_copys/CAPTIONS.html`.
4. Para un carrusel, sube Pxx_01 a Pxx_05 en ese orden. El caption se publica una vez para todo el carrusel.
5. Para historias, consulta `07_copys/HISTORIAS.html` y añade los stickers desde Instagram.
6. Para reels, las portadas están listas y los guiones están en `05_reels/GUIONES.html`. Falta grabación, montaje, subtítulos y audio apropiado.

## Presentación y edición

El diseño utiliza Fraunces, Montserrat y Barlow y los colores de la web. El símbolo y el logotipo parten de la identidad existente; el eslogan es una propuesta de campaña.

Edita `rrss/_generador/contenido.py` para cambiar los textos. Después ejecuta desde la raíz del proyecto:

```
python rrss/_generador/generar.py
python rrss/_generador/documentos.py
python rrss/_generador/galeria.py
python rrss/_generador/calendario.py
python rrss/_generador/documentos_html.py
```

El render usa Pillow y las herramientas incluidas en `_generador/vendor`. Las fuentes, licencias y recursos están dentro de `_recursos`. El ZIP es un kit de publicación, no incluye el entorno del generador.

## Estado

Todo rrss está excluido de Git mediante `/rrss/`. Las piezas no se han publicado ni programado en ninguna cuenta.

Se han verificado dimensiones, ajuste de texto, límites de captions, archivos enlazados y sintaxis de la galería. Se han inspeccionado visualmente las hojas de contacto del feed, muestras de historias y carrusel, equipo, portfolio y avatar.

Las cifras de conversión y testimonios no validados del código de la web se han excluido. Consulta `09_fuentes/FUENTES_Y_CRITERIOS.md` para conocer qué información y recursos se han usado.

El calendario HTML permite filtrar por semana y formato, elegir un lunes de inicio, abrir las piezas con sus textos y utilizar la impresión del navegador para guardar un PDF. Las versiones Markdown y CSV siguen disponibles.

# Calendario editorial · 8 semanas

Empieza el lunes que elijas. Los días son una propuesta; no hay horas óptimas universales ni resultados prometidos. Los reels son opcionales y sustituyen una publicación de esa semana.

## Semana 1
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P01 | Marca |
| Miércoles | Carrusel | P02 | Servicios |
| Viernes | Post | P03 | Proyecto |
| Domingo | Post | P04 | Diseño |
| Martes | Historia | S01 | marca |
| Jueves | Historia | S02 | encuesta |
| Sábado | Historia | S03 | proyecto |
| Domingo | Historia | S04 | crm |
| Opcional: sustituir un post | Reel | R01 | Tu web, en tres preguntas. |
## Semana 2
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P05 | Educación |
| Miércoles | Carrusel | P06 | Proceso |
| Viernes | Post | P07 | Proyecto |
| Domingo | Post | P08 | CRM |
| Martes | Historia | S05 | educacion |
| Jueves | Historia | S06 | proceso |
| Sábado | Historia | S07 | proyecto |
| Domingo | Historia | S08 | diseno |
| Opcional: sustituir un post | Reel | R02 | Así empieza una web. |
## Semana 3
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P09 | Marca |
| Miércoles | Carrusel | P10 | Educación |
| Viernes | Post | P11 | Proyecto |
| Domingo | Post | P12 | Marca |
| Martes | Historia | S09 | crm |
| Jueves | Historia | S10 | educacion |
| Sábado | Historia | S11 | proyecto |
| Domingo | Historia | S12 | conversacion |
| Opcional: sustituir un post | Reel | R03 | Una web. Tu contenido. |
## Semana 4
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P13 | CRM |
| Miércoles | Carrusel | P14 | Educación |
| Viernes | Post | P15 | Proyecto |
| Domingo | Post | P16 | Marca |
| Martes | Historia | S13 | proyecto |
| Jueves | Historia | S14 | marca |
| Sábado | Historia | S15 | proceso |
| Domingo | Historia | S16 | contacto |
| Opcional: sustituir un post | Reel | R04 | Un proyecto, muchos detalles. |
## Semana 5
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P17 | Marketing |
| Miércoles | Carrusel | P18 | Educación |
| Viernes | Post | P19 | Proyecto |
| Domingo | Post | P20 | Equipo |
| Martes | Historia | S17 | marketing |
| Jueves | Historia | S18 | conversacion |
| Sábado | Historia | S19 | proyecto |
| Domingo | Historia | S20 | equipo |
| Opcional: sustituir un post | Reel | R05 | Más que una página web. |
## Semana 6
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P21 | CRM |
| Miércoles | Carrusel | P22 | CRM |
| Viernes | Post | P23 | Games |
| Domingo | Post | P24 | Desarrollo |
| Martes | Historia | S21 | crm |
| Jueves | Historia | S22 | crm |
| Sábado | Historia | S23 | games |
| Domingo | Historia | S24 | desarrollo |
| Opcional: sustituir un post | Reel | R06 | El equipo detrás de la web. |
## Semana 7
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P25 | Marca |
| Miércoles | Carrusel | P26 | Proceso |
| Viernes | Post | P27 | Games |
| Domingo | Post | P28 | Proceso |
| Martes | Historia | S25 | marca |
| Jueves | Historia | S26 | educacion |
| Sábado | Historia | S27 | games |
| Domingo | Historia | S28 | encuesta |
| Opcional: sustituir un post | Reel | R07 | También se puede jugar. |
## Semana 8
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P29 | Conversación |
| Miércoles | Carrusel | P30 | Portfolio |
| Viernes | Post | P31 | Diseño |
| Domingo | Post | P32 | Contacto |
| Martes | Historia | S29 | educacion |
| Jueves | Historia | S30 | portfolio |
| Sábado | Historia | S31 | servicios |
| Domingo | Historia | S32 | contacto |
| Opcional: sustituir un post | Reel | R08 | Tu idea, con un siguiente paso. |
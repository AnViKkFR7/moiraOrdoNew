# Calendario editorial · 12 semanas

Empieza el lunes que elijas. Los días son una propuesta; no hay horas óptimas universales ni resultados prometidos. Los reels son opcionales y sustituyen una publicación de esa semana.

## Semana 1
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P01 | Marca |
| Miércoles | Carrusel | P02 | Servicios |
| Viernes | Post | P03 | Proyecto |
| Domingo | Post | P04 | Diseño |
| Martes | Historia | S01 | marca |
| Jueves | Historia | S02 | encuesta |
| Sábado | Historia | S03 | proyecto |
| Domingo | Historia | S04 | crm |
| Historia adicional | Historia | S49 | proyecto |
| Opcional: sustituir un post | Reel | R01 | Tu web, en tres preguntas. |
## Semana 2
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P05 | Educación |
| Miércoles | Carrusel | P06 | Proceso |
| Viernes | Post | P47 | Portfolio |
| Domingo | Post | P33 | CRM |
| Martes | Historia | S05 | educacion |
| Jueves | Historia | S33 | crm |
| Sábado | Historia | S06 | proceso |
| Domingo | Historia | S07 | proyecto |
| Historia adicional | Historia | S50 | proyecto |
| Opcional: sustituir un post | Reel | R02 | Así empieza una web. |
## Semana 3
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P07 | Proyecto |
| Miércoles | Carrusel | P10 | Educación |
| Viernes | Post | P08 | CRM |
| Domingo | Post | P09 | Marca |
| Martes | Historia | S08 | diseno |
| Jueves | Historia | S34 | encuesta |
| Sábado | Historia | S09 | crm |
| Domingo | Historia | S35 | crm |
| Historia adicional | Historia | S51 | games |
| Opcional: sustituir un post | Reel | R03 | Una web. Tu contenido. |
## Semana 4
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P35 | CRM |
| Miércoles | Carrusel | P41 | Proyecto |
| Viernes | Post | P11 | Proyecto |
| Domingo | Post | P12 | Marca |
| Martes | Historia | S10 | educacion |
| Jueves | Historia | S36 | proyecto |
| Sábado | Historia | S11 | proyecto |
| Domingo | Historia | S12 | conversacion |
| Historia adicional | Historia | S52 | proyecto |
| Opcional: sustituir un post | Reel | R04 | Un proyecto, muchos detalles. |
## Semana 5
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P13 | CRM |
| Miércoles | Carrusel | P14 | Educación |
| Viernes | Post | P42 | Proyecto |
| Domingo | Post | P16 | Marca |
| Martes | Historia | S13 | proyecto |
| Jueves | Historia | S37 | crm |
| Sábado | Historia | S14 | marca |
| Domingo | Historia | S38 | proyecto |
| Historia adicional | Historia | S53 | proyecto |
| Opcional: sustituir un post | Reel | R09 | Un minuto dentro del CRM. |
## Semana 6
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P15 | Proyecto |
| Miércoles | Carrusel | P34 | CRM |
| Viernes | Post | P36 | CRM |
| Domingo | Post | P17 | Marketing |
| Martes | Historia | S15 | proceso |
| Jueves | Historia | S39 | crm |
| Sábado | Historia | S16 | contacto |
| Domingo | Historia | S17 | marketing |
| Historia adicional | Historia | S54 | proyecto |
| Opcional: sustituir un post | Reel | R05 | Más que una página web. |
## Semana 7
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P44 | Proyecto |
| Miércoles | Carrusel | P18 | Educación |
| Viernes | Post | P19 | Proyecto |
| Domingo | Post | P20 | Equipo |
| Martes | Historia | S18 | conversacion |
| Jueves | Historia | S40 | proyecto |
| Sábado | Historia | S19 | proyecto |
| Domingo | Historia | S41 | encuesta |
| Historia adicional | Historia | S55 | games |
| Opcional: sustituir un post | Reel | R06 | El equipo detrás de la web. |
## Semana 8
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P21 | CRM |
| Miércoles | Carrusel | P43 | Proyecto |
| Viernes | Post | P38 | CRM |
| Domingo | Post | P24 | Desarrollo |
| Martes | Historia | S20 | equipo |
| Jueves | Historia | S42 | games |
| Sábado | Historia | S21 | crm |
| Domingo | Historia | S22 | crm |
| Historia adicional | Historia | S56 | portfolio |
| Opcional: sustituir un post | Reel | R10 | Regia Mare, de la web al panel. |
## Semana 9
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P48 | Proyecto |
| Miércoles | Carrusel | P22 | CRM |
| Viernes | Post | P27 | Games |
| Domingo | Post | P39 | CRM |
| Martes | Historia | S23 | games |
| Jueves | Historia | S43 | crm |
| Sábado | Historia | S24 | desarrollo |
| Domingo | Historia | S44 | crm |
| Opcional: sustituir un post | Reel | R07 | También se puede jugar. |
## Semana 10
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P25 | Marca |
| Miércoles | Carrusel | P45 | Proyecto |
| Viernes | Post | P37 | CRM |
| Domingo | Post | P28 | Proceso |
| Martes | Historia | S25 | marca |
| Jueves | Historia | S45 | portfolio |
| Sábado | Historia | S26 | educacion |
| Domingo | Historia | S27 | games |
| Opcional: sustituir un post | Reel | R11 | Reservar sin rodeos. |
## Semana 11
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P23 | Games |
| Miércoles | Carrusel | P26 | Proceso |
| Viernes | Post | P40 | CRM |
| Domingo | Post | P29 | Conversación |
| Martes | Historia | S28 | encuesta |
| Jueves | Historia | S46 | crm |
| Sábado | Historia | S29 | educacion |
| Domingo | Historia | S47 | encuesta |
| Opcional: sustituir un post | Reel | R12 | Cuatro webs en veinte segundos. |
## Semana 12
| Día | Formato | Pieza | Tema |
|---|---|---|---|
| Lunes | Post | P31 | Diseño |
| Miércoles | Carrusel | P46 | Games |
| Viernes | Carrusel | P30 | Portfolio |
| Domingo | Post | P32 | Contacto |
| Martes | Historia | S30 | portfolio |
| Jueves | Historia | S48 | crm |
| Sábado | Historia | S31 | servicios |
| Domingo | Historia | S32 | contacto |
| Opcional: sustituir un post | Reel | R08 | Tu idea, con un siguiente paso. |
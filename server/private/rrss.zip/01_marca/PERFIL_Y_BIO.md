# Propuesta de perfil

Nombre visible: **Moira Ordo | Web & CRM**

Bio sugerida (129 caracteres, incluidos saltos de línea):

```
Webs a medida + CRM propio.
Diseño, desarrollo y marketing para tu negocio.
Vilanova i la Geltrú · España
Cuéntanos tu proyecto ↓
```

Avatar recomendado: `avatar_navy.png`.

Usuario: mantener el de vuestra cuenta actual. No se ha supuesto que ningún @ esté disponible.

Enlace principal propuesto:
https://moiraordo.es/contacto?utm_source=instagram&utm_medium=social&utm_campaign=rrss_base_8s

Enlaces complementarios si usáis varios en el perfil:
- Portfolio: https://moiraordo.es/proyectos?utm_source=instagram&utm_medium=social&utm_campaign=rrss_base_8s
- Demo: https://moiraordo.es/crm?utm_source=instagram&utm_medium=social&utm_campaign=rrss_base_8s

## Primeras tres publicaciones a destacar en el perfil

1. P01: propuesta de valor.
2. P02: qué hacemos.
3. P30: portfolio.

## Destacadas propuestas

- Webs: S03, S07, S11, S13, S19, S36, S38, S40 y S45.
- CRM: S04, S09, S21, S22, S33, S35, S39, S43, S46 y S48.
- Proceso: S06, S15 y S26.
- Equipo: S20, más historias reales grabadas por el equipo.
- Games: S23, S27 y S42.
- Contacto: S16 y S32.

Las cubiertas están en `06_destacadas`. Las historias se guardan en la destacada correspondiente después de publicarlas.

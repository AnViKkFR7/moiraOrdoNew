# Marca para Instagram · Moira Ordo

## La idea central

Una consultora digital que conecta diseño, desarrollo, contenido y herramientas para que un pequeño negocio tenga una presencia digital que pueda utilizar y gestionar.

**Mensaje principal:** Tu web. Tu contenido. Tu control.

**Propuesta de eslogan de campaña:** Diseño con intención. Tecnología a medida.

Es una propuesta editorial para este banco de contenidos, no un cambio automático del eslogan de la web.

Alternativas para diferentes piezas:

1. De la idea a una web que puedes gestionar.
2. Una web a tu medida. Un equipo a tu lado.
3. Tu negocio cambia. Tu web te acompaña.
4. Diseño que te representa. Tecnología que te sirve.
5. Damos forma a lo que tu negocio necesita.
6. Web, contenido y herramientas con sentido.
7. Lo digital, con orden.
8. Una presencia online que no se improvisa. (Mensaje ya utilizado en la web.)

## Paleta

| Uso | Color |
|---|---|
| Fondo crema | #FCFBF7 |
| Texto y fondo azul noche | #00051E |
| Azul principal | #4692FF |
| Azul claro | #82DAFF |
| Azul de texto sobre claro | #1F63CC |
| Melocotón de apoyo | #FFE2D2 |
| Amarillo de apoyo | #FFCF80 |
| Texto secundario | #585B6A |

La paleta procede de `src/styles/variables.css` y no cambia. Lo que cambia es cómo se usa en Instagram: los colores se mezclan en **mallas pastel** (crema, melocotón, amarillo y celeste difuminados) y el azul noche aparece como fondo profundo con resplandores azules. El azul saturado ya no se usa como fondo plano.

## Sistema visual de Instagram (v4)

- **Fondos:** cinco ambientes (noche, tinta, amanecer, cielo, crema, melocotón) con manchas de color difuminadas y un grano muy fino. En los carruseles el fondo continúa de una diapositiva a la siguiente.
- **Cristal translúcido:** chips, tarjetas y botones con desenfoque y borde luminoso, que flotan sobre las capturas.
- **Titulares:** Fraunces muy grande, con la última línea en cursiva y degradado azul. Es el mismo tono editorial de la web, con más presencia.
- **Dispositivos reales:** cada web se enseña con la captura completa en un navegador, un móvil o un portátil, sin recortes. Las capturas están en `_recursos/pantallas`.
- **Motivo:** el círculo orbital de la web, ampliado como elemento gráfico que atraviesa las piezas.
- **Detalles:** sello circular de texto (“Caso real”), chips con icono y botones con flecha.
- **Formato:** feed y carruseles en JPG 1080 × 1350 y historias y reels en JPG 1080 × 1920, mejor para Instagram. Avatares, destacadas y piezas de marca siguen en PNG.
- Las imágenes ya no llevan el código de pieza (P01…): el nombre del archivo identifica cada una.

## Tipografías

- Fraunces: titulares editoriales.
- Montserrat: subtítulos, textos y datos.
- Barlow Bold: logotipo tipográfico, siguiendo la cabecera actual de la web.

Se incluyen copias de las fuentes convertidas desde los paquetes del proyecto y sus licencias en `_recursos/fuentes`. No dependen de Google Fonts ni de una conexión externa.

## Logo y avatar

El avatar reutiliza la M de `public/favicon.svg`. El logotipo tipográfico toma la identidad de la cabecera actual. No se ha inventado un símbolo nuevo ni sustituido la marca del sitio.

- `avatar_cream.png`, `avatar_navy.png`, `avatar_blue.png`: 1080 × 1080. Propuesta recomendada de perfil: azul noche.
- `logotipo_oscuro.png` y `logotipo_claro.png`: fondo transparente.
- `logotipo_oscuro.svg` y `logotipo_claro.svg`: contornos vectoriales.
- `simbolo-original.svg`: copia del símbolo existente.
- `eslogan_cream.png` y `eslogan_navy.png`: aplicaciones editoriales del eslogan.

El archivo antiguo `src/assets/images/logo.png` se conserva en recursos como referencia histórica; no se mezcla con el sistema actual en las piezas.

## Composición

Feed: 1080 × 1350, RGB. Historias y portadas de reels: 1080 × 1920. Destacadas: 1080 × 1080.

Las piezas reservan márgenes amplios y utilizan títulos grandes. Las historias dejan espacio central inferior para añadir las pegatinas indicadas. Las portadas de reels concentran el titular en la zona central, pero conviene revisar el recorte en la vista de perfil antes de guardar.

Las capturas de webs se presentan dentro de un marco de navegador. La fotografía de Arquelia se etiqueta como imagen del portfolio: no se hace pasar por una captura real.

## Voz

Castellano de España. Tuteo, claridad y cercanía profesional. Explicar qué se hace y por qué ayuda, con ejemplos concretos.

Usar: «gestionas el contenido», «empezamos por entender tu negocio», «trabajamos por pasos», «explora el proyecto».

Evitar: resultados garantizados, «la mejor agencia», «vende solo», tecnicismos sin contexto y comparaciones que desprecien otras soluciones.

# Marca para Instagram · Moira Ordo

## La idea central

Una consultora digital que conecta diseño, desarrollo, contenido y herramientas para que un pequeño negocio tenga una presencia digital que pueda utilizar y gestionar.

**Mensaje principal:** Tu web. Tu contenido. Tu control.

**Propuesta de eslogan de campaña:** Diseño con intención. Tecnología a medida.

Es una propuesta editorial para este banco de contenidos, no un cambio automático del eslogan de la web.

Alternativas para diferentes piezas:

1. De la idea a una web que puedes gestionar.
2. Una web a tu medida. Un equipo a tu lado.
3. Tu negocio cambia. Tu web te acompaña.
4. Diseño que te representa. Tecnología que te sirve.
5. Damos forma a lo que tu negocio necesita.
6. Web, contenido y herramientas con sentido.
7. Lo digital, con orden.
8. Una presencia online que no se improvisa. (Mensaje ya utilizado en la web.)

## Paleta

| Uso | Color |
|---|---|
| Fondo crema | #FCFBF7 |
| Texto y fondo azul noche | #00051E |
| Azul principal | #4692FF |
| Azul claro | #82DAFF |
| Azul de texto sobre claro | #1F63CC |
| Melocotón de apoyo | #FFE2D2 |
| Amarillo de apoyo | #FFCF80 |
| Texto secundario | #585B6A |

La paleta procede de `src/styles/variables.css`. Azul noche + crema es la base. Azul y melocotón ayudan a alternar las piezas sin cambiar de identidad.

## Tipografías

- Fraunces: titulares editoriales.
- Montserrat: subtítulos, textos y datos.
- Barlow Bold: logotipo tipográfico, siguiendo la cabecera actual de la web.

Se incluyen copias de las fuentes convertidas desde los paquetes del proyecto y sus licencias en `_recursos/fuentes`. No dependen de Google Fonts ni de una conexión externa.

## Logo y avatar

El avatar reutiliza la M de `public/favicon.svg`. El logotipo tipográfico toma la identidad de la cabecera actual. No se ha inventado un símbolo nuevo ni sustituido la marca del sitio.

- `avatar_cream.png`, `avatar_navy.png`, `avatar_blue.png`: 1080 × 1080. Propuesta recomendada de perfil: azul noche.
- `logotipo_oscuro.png` y `logotipo_claro.png`: fondo transparente.
- `logotipo_oscuro.svg` y `logotipo_claro.svg`: contornos vectoriales.
- `simbolo-original.svg`: copia del símbolo existente.
- `eslogan_cream.png` y `eslogan_navy.png`: aplicaciones editoriales del eslogan.

El archivo antiguo `src/assets/images/logo.png` se conserva en recursos como referencia histórica; no se mezcla con el sistema actual en las piezas.

## Composición

Feed: 1080 × 1350, RGB. Historias y portadas de reels: 1080 × 1920. Destacadas: 1080 × 1080.

Las piezas reservan márgenes amplios y utilizan títulos grandes. Las historias dejan espacio central inferior para añadir las pegatinas indicadas. Las portadas de reels concentran el titular en la zona central, pero conviene revisar el recorte en la vista de perfil antes de guardar.

Las capturas de webs se presentan dentro de un marco de navegador. La fotografía de Arquelia se etiqueta como imagen del portfolio: no se hace pasar por una captura real.

## Voz

Castellano de España. Tuteo, claridad y cercanía profesional. Explicar qué se hace y por qué ayuda, con ejemplos concretos.

Usar: «gestionas el contenido», «empezamos por entender tu negocio», «trabajamos por pasos», «explora el proyecto».

Evitar: resultados garantizados, «la mejor agencia», «vende solo», tecnicismos sin contexto y comparaciones que desprecien otras soluciones.

# Roadmap Instagram · Moira Ordo

Público: pequeños negocios de España. Idioma: castellano. Voz: cercana, profesional y concreta.
Objetivo: explicar la propuesta, mostrar proyectos reales y facilitar conversaciones cualificadas.

## Ejecución

- [x] 1. Auditar identidad, servicios y portfolio del repositorio.
- [x] 2. Crear rrss y excluir toda la carpeta de Git.
- [x] 3. Definir mensajes, eslogan, bio y sistema de diseño a partir de la marca existente.
- [x] 4. Redactar 32 publicaciones (24 estáticas y 8 carruseles de 5 diapositivas).
- [x] 5. Exportar 64 imágenes de feed en PNG 1080 × 1350.
- [x] 6. Crear 32 historias en PNG 1080 × 1920, con instrucciones para stickers nativos.
- [x] 7. Preparar 8 guiones de reels, 8 portadas y 6 cubiertas de destacadas.
- [x] 8. Preparar variantes de logo, avatar y eslogan, conservando la identidad existente.
- [x] 9. Distribuir el contenido en un calendario de 8 semanas sin fechas obligatorias.
- [x] 10. Entregar textos, alt, CTA y hashtags en Markdown, JSON y CSV.
- [x] 11. Generar una galería navegable, hojas de contacto y validar tamaños, legibilidad y textos.
- [x] 12. Comprobar que Git ignora rrss y documentar el uso y las siguientes acciones.

## Criterios de entrega

Piezas utilizables, no solo ideas. PNG listos para subir y fuentes editables con generador.
No se publicará ni programará contenido en ninguna cuenta.
La prioridad es mostrar web + CRM + acompañamiento; software y juegos amplían el portfolio.
No se presentarán métricas o testimonios no validados como hechos.
Las pegatinas interactivas de historias se añaden manualmente desde Instagram.
El calendario usa semanas relativas para comenzar cuando convenga.

## Resultado de la ejecución

Entregados 117 PNG y 6 SVG de publicación/marca, 32 captions, 8 guiones de vídeo, calendario de 8 semanas, guía de marca, bio, fuentes editables, galería y paquete ZIP. Los reels son guiones y portadas: su grabación y montaje quedan como siguientes acciones, fuera de la producción estática de este lote.

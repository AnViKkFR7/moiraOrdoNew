# Estrategia editorial · Primer ciclo de 8 semanas

## Para quién

Pequeños negocios y equipos de España que necesitan presentar mejor su trabajo, recibir consultas o gestionar contenido sin depender de un desarrollador para cada actualización.

## Qué queremos que se entienda

1. No hacemos solo pantallas bonitas: diseñamos la experiencia y construimos las herramientas.
2. La web puede conectarse al CRM propio para gestionar contenido y operativa.
3. El mismo equipo puede acompañar diseño, desarrollo y marketing.
4. Hay proyectos reales y públicos que permiten ver el trabajo.

## Pilares

- Identidad y propuesta: quiénes somos y qué diferencia nuestro enfoque.
- Educación práctica: revisar una web, preparar un briefing, pensar en móvil y cuidar el contacto.
- Portfolio: proyectos con nombre, contexto y enlace.
- Producto y proceso: cómo trabajamos y qué se explora en el CRM.
- Equipo y conversación: personas, preguntas y contacto.
- Games: una línea complementaria del estudio, con presencia acotada para no diluir el mensaje principal.

## Ritmo propuesto

Cuatro publicaciones de feed y cuatro historias por semana. Los 8 reels son una reserva de ideas con portada, no vídeos terminados. Si grabáis uno, puede sustituir a un post de esa semana para no aumentar la carga.

Empezar con este ritmo solo si resulta sostenible. Si preferís dos posts por semana, el mismo banco cubre 16 semanas: mantener el orden de las piezas y repartir las historias.

## Antes de publicar cada pieza

Leer el texto, revisar que el enlace de perfil corresponda a la llamada a la acción y comprobar el recorte de la imagen en la aplicación. En las historias con instrucciones, añadir la encuesta, pregunta o enlace nativo.

Las imágenes no contienen precios. El diseño y el desarrollo son servicios distintos en la web y no se ha creado una tarifa combinada ficticia.

## Qué observar al terminar cada semana

Conversaciones y solicitudes que llegan, visitas al perfil, respuestas a historias, guardados y qué temas generan preguntas útiles. Registrar la fuente de las consultas cuando se disponga de ella.

No sumar los clics de un enlace como si fueran clientes. No atribuir todo un aumento de solicitudes a una publicación sin evidencia.

Al terminar las semanas 4 y 8, elegir qué formatos merecen una segunda versión y qué preguntas se pueden convertir en el siguiente carrusel.
